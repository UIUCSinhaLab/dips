#include "parameters_cache.h"
#include <math.h>

/////////////////////////////////////////////////////////////////////
///// SYNOPSIS //////////////////////////////////////////////////////
///// A single global object of this class is maintained. ///////////
///// It stores the last calculated values of counts, derivatives, //
///// and deltaF's for each promoter. Also the prior probs of ///////
///// each wtmx. ////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////


void Cache::Destroy()
{
  for (int l=0; l<_wmlength; l++) delete [] deltaF_lk[l];
  delete [] deltaF_lk;

  for (int i=0; i<_numseqs; i++) {
    for (int j=0; j<_wmlength; j++) {
      delete [] derivs[i][j];
    }
    delete [] derivs[i];
  }
  delete [] derivs;
  delete [] counts;
}

void Cache::Initialize(int numseqs, int wmlength)
{
  _numseqs = numseqs;
  _wmlength = wmlength;

  counts = new DTYPE[numseqs];
  derivs = new DTYPE**[numseqs];
  for (int i=0; i<numseqs; i++) {
    derivs[i] = new DTYPE *[wmlength];
    for (int j=0; j<wmlength; j++) {
      derivs[i][j] = new DTYPE[4];
    }
  }
  
  for (int i=0; i<MAX_SEQ; i++) 
    for (int j=0; j<MAX_WTMX; j++) 
      priors[i][j] = 0;
  usepriors = false;
  trainfreewmandbkgonly = false;

  // also initialize the deltaF_lk
  deltaF_lk = new DTYPE*[_wmlength];
  for (int l=0; l<_wmlength; l++) {
    deltaF_lk[l] = new DTYPE[4];
  }
      
}


void Cache::AdjustPriorsForNewWtMx(int wmindex, float prior_probability)
{
  if (prior_probability >= 0) {
    for (int i=0; i<_numseqs; i++) {
#ifndef _UNIFORMPRIORS_
      priors[i][wmindex+1] = priors[i][wmindex];
      priors[i][wmindex] = prior_probability;
      priors[i][wmindex+1] -= priors[i][wmindex];
      // fprintf(stderr,"motif = %g bkg = %g\n",priors[i][wmindex],priors[i][wmindex+1]);
#else
      for (int j=0; j<=wmindex; j++) priors[i][j] = prior_probability;
      priors[i][wmindex+1] = 1 - prior_probability*(wmindex+1);
#endif
    }
  }
  else {
    fprintf(stderr,"Error in Cache::AdjustPriorsForNewWtMx\n");
    exit(1);
  }
}

void Cache::Clear()
{  
  for (int i=0; i<_numseqs; i++) {
    for (int j=0; j<_wmlength; j++) {  
      for (int k=0; k<4; k++) {
	derivs[i][j][k] = 0;
      }
    }
    counts[i] = 0;
  }

  for (int l=0; l<_wmlength; l++) {
    for (int k=0; k<4; k++) {
      deltaF_lk[l][k] = 0;
    }
  }
}

void Cache::PrintCounts(FILE *fp)
{
  for (int i=0; i<_numseqs; i++) {
    fprintf(fp,"%.1f\t",counts[i]);
  }
  fprintf(fp,"\n");
}
