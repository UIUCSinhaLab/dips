#ifndef _PARAMETERS_CACHE_H_
#define _PARAMETERS_CACHE_H_

#include "typedefs.h"
#include <stdio.h>
#include <stdlib.h>

#define MAX_SEQ 300
#define MAX_WTMX 20

struct Cache {
  DTYPE *counts;          // posterior score of current Wtmx in each sequence
  DTYPE ***derivs;        // derivative of posterior score, w.r.t each column and base
  int _numseqs;           
  int _wmlength;

  DTYPE **deltaF_lk;      // used to speed up estimatedeltaf(fast)

  DTYPE priors[MAX_SEQ][MAX_WTMX]; // assumes at most 100 sequences, and at most 100 wtmxs
  bool  usepriors;        // if false, then dont use the priors[][] 
  bool  trainfreewmandbkgonly; // once the other wtmxs' priors have been trained, this is set,
                          // so that they are fixed, and only p_m and p_b will be trained, if at all.
  void  AdjustPriorsForNewWtMx(int wmindex, float prior_probability);

  void Initialize(int numseqs, int wmlength);  
  void Clear();
  void Destroy();
  void PrintCounts(FILE *fp);
};





#endif
