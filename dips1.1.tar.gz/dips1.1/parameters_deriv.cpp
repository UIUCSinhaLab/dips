#include "parameters_deriv.h"
#include "optimize.h"

//////////////////////////////////////////////////////////////////////
///// SYNOPSIS ///////////////////////////////////////////////////////
///// Extends the Parameters_H0 class by implementing its derivative//
//////////////////////////////////////////////////////////////////////


Parameters_Deriv::Parameters_Deriv()
{
  _alpha_d = NULL;
  _beta_d = NULL;
  _A_d = NULL;
  _Al_d_window = NULL;
  _wmindex = -1;
}

Parameters_Deriv::~Parameters_Deriv()
{
  Destroy();
}

Parameters_Deriv::Parameters_Deriv(const Parameters_Deriv &p)
  : Parameters_H0(p)
{
  Copy(p);
}

Parameters_Deriv& Parameters_Deriv::operator=(const Parameters_Deriv &p)
{
  if (this != &p) {
    this->Parameters_H0::operator=(p);
    Destroy();
    Copy(p);
  }
  return *this;
}

void Parameters_Deriv::Copy(const Parameters_Deriv &p)
{
  if (p._wmindex >= 0) {
    _wmindex = p._wmindex;
    WtMx * wm = p._wmc->WM(p._wmindex);
    int wmlength = wm->Length();
    Window *window = (*_windows)[0];
    int winlength = window->Length();

    _alpha_d = new DTYPE **[wmlength];
    _beta_d = new DTYPE **[wmlength];
    _A_d = new DTYPE *[wmlength];
    _Al_d_window = new DTYPE **[wmlength];
    for (int i=0; i<wmlength; i++) {
      _alpha_d[i] = new DTYPE *[4];
      _beta_d[i] = new DTYPE *[4];
      _A_d[i] = new DTYPE[4];
      _Al_d_window[i] = new DTYPE *[4];
      for (int j=0; j<4; j++) {
	_alpha_d[i][j] = new DTYPE[winlength];
	_beta_d[i][j] = new DTYPE[winlength];
	_A_d[i][j] = p._A_d[i][j];
	_Al_d_window[i][j] = new DTYPE[winlength];
	for (int k=0; k<winlength; k++) {
	  _alpha_d[i][j][k] = p._alpha_d[i][j][k];
	  _beta_d[i][j][k] = p._beta_d[i][j][k];
	  _Al_d_window[i][j][k] = p._Al_d_window[i][j][k];
	}
      }
    }    
  }
}
      
void Parameters_Deriv::Destroy()
{
  if (_wmindex >= 0) {
    WtMx * wm = _wmc->WM(_wmindex);
    int wmlength = wm->Length();

    for (int i=0; i<wmlength; i++) {
      for (int j=0; j<4; j++) {
	delete [] _alpha_d[i][j];
	delete [] _beta_d[i][j];
	delete [] _Al_d_window[i][j];
      }
      delete [] _alpha_d[i];
      delete [] _beta_d[i];      
      delete [] _A_d[i];
      delete [] _Al_d_window[i];
    }
    delete [] _alpha_d;
    delete [] _beta_d;
    delete [] _A_d;
    delete [] _Al_d_window;
  }
}

void Parameters_Deriv::SetFreeWMIndex(int wmi)
{
  _wmindex = wmi;
  
  WtMx * wm = _wmc->WM(_wmindex);
  int wmlength = wm->Length();
  Window *window = (*_windows)[0];
  int winlength = window->Length();
  
  _alpha_d = new DTYPE **[wmlength];
  _beta_d = new DTYPE **[wmlength];
  _A_d = new DTYPE *[wmlength];
  _Al_d_window = new DTYPE **[wmlength];
  for (int i=0; i<wmlength; i++) {
    _alpha_d[i] = new DTYPE *[4];
    _beta_d[i] = new DTYPE *[4];
    _A_d[i] = new DTYPE[4];
    _Al_d_window[i] = new DTYPE *[4];
    for (int j=0; j<4; j++) {
      _alpha_d[i][j] = new DTYPE[winlength];
      _beta_d[i][j] = new DTYPE[winlength];
      _A_d[i][j] = 0;
      _Al_d_window[i][j] = new DTYPE[winlength];
      for (int k=0; k<winlength; k++) {
	_alpha_d[i][j][k] = 0; 
	_beta_d[i][j][k] = 0;
	_Al_d_window[i][j][k] = 0;
      }
    }
  }
}

void Parameters_Deriv::ForwardDeriv()
{
  int i;
  int bkgIndex = BackgroundIndex();  // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  int max_wm_length = 0;
  for (i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
    if (_wm_len[i] > max_wm_length) max_wm_length = _wm_len[i];
  }

  Window *window = _currentWindow;
  int length = window->Length();
  int wmlength = _wm_len[_wmindex];

                                       // Clear up previous information
  for (int k=0; k<wmlength; k++) {
    for (int alpha=0; alpha<4; alpha++) {
      for (int l=0; l<length; l++) {
	_alpha_d[k][alpha][l] = 0;
      }
    }
  }

                                       // Base conditions (l==0) :-
  if (window->AmbiguousCharAt(0)) {    // 'N' or 'X' at position 0, alpha[0] = 1
    for (int k=0; k<wmlength; k++) {
      for (int alpha=0; alpha<4; alpha++) {
	_alpha_d[k][alpha][0] = 0;
      }
    }
  }
  else {                               // usual case: a known nucleotide at position 0
    for (int k=0; k<wmlength; k++) {
      for (int alpha=0; alpha<4; alpha++) {
	if (_wm_len[_wmindex]==1) {
	  _alpha_d[k][alpha][0] = _c[0]*_pi[_wmindex]*ComputeSequenceProbabilityDerivative(window,0,0,wm[_wmindex],k,alpha);
	}
      }
    }
  }
                                       // Recurrences :-
  for (int l=1; l<length; l++) {       // compute alpha[l]
    if (window->AmbiguousCharAt(l)) {  // 'N' or 'X' here - propagate the previous alpha
      for (int k=0; k<wmlength; k++) {
	for (int alpha=0; alpha<4; alpha++) {
	  _alpha_d[k][alpha][l] = _alpha_d[k][alpha][l-1]*_c[l];
	}
      }
    }
    else {                             // usual case: known nucleotude at this position
      for (int k=0; k<wmlength; k++) {
	for (int alpha=0; alpha<4; alpha++) {
	  DTYPE  sum = 0;
	  for (int i=0; i<_numWM; i++) {
	    int wm_len_i = _wm_len[i];
	    if (l-wm_len_i+1<0)
	      continue;
	    if (l-wm_len_i+1==0 && i==_wmindex) {
	      DTYPE  scale_factor = _cij[0][l];
	      sum += scale_factor*_pi[i]*ComputeSequenceProbabilityDerivative(window,0,l,wm[i],k,alpha);
	      continue;
	    }
	    DTYPE  scale_factor = (wm_len_i>1?_cij[l-wm_len_i+1][wm_len_i-1]:_c[l]);
	    sum += _alpha_d[k][alpha][l-wm_len_i]*scale_factor*_pi[i]*ComputeSequenceProbability(window,l-wm_len_i+1,l,wm[i]);
	    if (i==_wmindex) {
	      sum += _alpha[l-wm_len_i]*scale_factor*_pi[i]*ComputeSequenceProbabilityDerivative(window,l-wm_len_i+1,l,wm[i],k,alpha);
	    }
	  }
	  _alpha_d[k][alpha][l] = sum;
	}
      }
    }                       
  }

                                      // Clean up
  delete [] wm;
}

void Parameters_Deriv::BackwardDeriv()
{
  int i;
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }

  Window *window = _currentWindow;
  int length = window->Length();
  int wmlength = _wm_len[_wmindex];
  
                                    // Clear up previous information
  for (int k=0; k<wmlength; k++) {
    for (int alpha=0; alpha<4; alpha++) {
      for (int l=0; l<length; l++) {
	_beta_d[k][alpha][l] = 0;
      }
    }
  }

                                    // Base conditions :-
  if (window->AmbiguousCharAt(length-1)) {   // 'N' or 'X' here
    for (int k=0; k<wmlength; k++) {
      for (int alpha=0; alpha<4; alpha++) {
	_beta_d[k][alpha][length-1] = 0;
      }
    }
  }
  else {                            // usual case: known nucleotide at this position
    for (int k=0; k<wmlength; k++) {
      for (int alpha=0; alpha<4; alpha++) {
	// if (_wm_len[_wmindex]==1) {
	_beta_d[k][alpha][length-1] = _c[length-1]*_pi[_wmindex]*ComputeSequenceProbabilityDerivative(window,length-1,length-1,wm[_wmindex],k,alpha);
	// }
      }
    }
  }
                                    // Recurrences :-
  for (int l=length-2; l>=1; l--) { // need beta only for length-1 .. 1
    if (window->AmbiguousCharAt(l)) {// 'N' or 'X' here, propagate the previous _beta
      for (int k=0; k<wmlength; k++) {
	for (int alpha=0; alpha<4; alpha++) {
	  _beta_d[k][alpha][l] = _c[l]*_beta_d[k][alpha][l+1];
	}
      }
      continue;
    }
                                    // usual case: known nucleotide at this position
    for (int k=0; k<wmlength; k++) {
      for (int alpha=0; alpha<4; alpha++) {
	DTYPE  sum = 0;
	for (i=0; i<_numWM; i++) {      // any wm_i (including the background) may start at position l
	  int wm_len_i = _wm_len[i];
	  if (l+wm_len_i<length) {     // wm_i starts and ends before length - 1, so there is a following beta also
	    DTYPE  scale_factor = (wm_len_i>1?_cij[l][wm_len_i-1]:_c[l]);
	    sum += scale_factor*_pi[i]*ComputeSequenceProbability(window,l,l+wm_len_i-1,wm[i])
	      *_beta_d[k][alpha][l+wm_len_i];
	    if (i==_wmindex) {
	      sum += scale_factor*_pi[i]*ComputeSequenceProbabilityDerivative(window,l,l+wm_len_i-1,wm[i],k,alpha)
		*_beta[l+wm_len_i];
	    }
	  }
	  else {                        // wm_i starts here but either it doesnt end, or ends at last position
	    if (i==_wmindex) { //  && (l+k)<length) {
	      DTYPE  scale_factor = _cij[l][length-1-l];
	      sum += scale_factor*_pi[i]*ComputeSequenceProbabilityDerivative(window,l,length-1,wm[i],k,alpha);
	    }
	  }
	}
	_beta_d[k][alpha][l] = sum;
      }
    }
  }
  // Clean up
  delete [] wm;
}

void Parameters_Deriv::PrepareForDerivativeComputations()
{
  int i;
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }

  Window *window = _currentWindow;
  int length = window->Length();
  int wmlength = wm[_wmindex]->Length();

                                    // Clear up previous information
  for (int k=0; k<wmlength; k++) {
    for (int alpha=0; alpha<4; alpha++) {      
      _A_d[k][alpha] = -1;
    }
  }

  
  for (int k=0; k<wmlength; k++) {
    for (int alpha=0; alpha<4; alpha++) {      
      int i=_wmindex;
      int wm_len_i = _wm_len[i];

      _A_d[k][alpha] = 0;
      for (int l=0; l<length; l++) {  // ... by summing _Al_d_window[k][alpha][l] over all l
	if (window->AmbiguousCharAt(l)) { // 'N' or 'X' at this position, cant have pi at this position
	  _Al_d_window[k][alpha][l] = 0;
	  continue;
	}
	if (l==0) {                   // case 1: no alpha term defined for l-1, only X_l and Z_l
	  DTYPE sum = 0;
	  sum += _cij[l][wm_len_i-1]*_pi[i]
	    *ComputeSequenceProbabilityDerivative(window,l,l+wm_len_i-1,wm[i],k,alpha)
	    *_beta[l+wm_len_i];
	  sum += _cij[l][wm_len_i-1]*_pi[i]
	    *ComputeSequenceProbability(window,l,l+wm_len_i-1,wm[i])
	    *_beta_d[k][alpha][l+wm_len_i];
	  
	  _Al_d_window[k][alpha][l] = sum;
	  _A_d[k][alpha] += sum;
	  continue;
	}
	if (l+wm_len_i>=length) {     // case 2: no beta term defined for l+wm_len[i], only X_l and Y_l
	  DTYPE sum = 0;
	  sum += _alpha[l-1]*_cij[l][length-1-l]*_pi[i]
	    *ComputeSequenceProbabilityDerivative(window,l,length-1,wm[i],k,alpha);
	  sum += _alpha_d[k][alpha][l-1]*_cij[l][length-1-l]*_pi[i]
	    *ComputeSequenceProbability(window,l,length-1,wm[i]);

	  _Al_d_window[k][alpha][l] = sum;
	  _A_d[k][alpha] += sum;
	  continue;
	}
	                            // general condition: use both alpha and beta
	DTYPE sum = 0;
	sum += _alpha[l-1]*_cij[l][wm_len_i-1]*_pi[i]
	  *ComputeSequenceProbabilityDerivative(window,l,l+wm_len_i-1,wm[i],k,alpha)
	  *_beta[l+wm_len_i];
	sum += _alpha_d[k][alpha][l-1]*_cij[l][wm_len_i-1]*_pi[i]
	  *ComputeSequenceProbability(window,l,l+wm_len_i-1,wm[i])
	  *_beta[l+wm_len_i];
	sum += _alpha[l-1]*_cij[l][wm_len_i-1]*_pi[i]
	  *ComputeSequenceProbability(window,l,l+wm_len_i-1,wm[i])
	  *_beta_d[k][alpha][l+wm_len_i];

	_Al_d_window[k][alpha][l] = sum;
	_A_d[k][alpha] += sum;
	// fprintf(stderr,"_A_d_k_alpha for l=%d k=%d l=%d is %.4f\n",l,k,alpha,sum);
      }
    }
  }
                                    // Clean up
  delete [] wm;
}

void Parameters_Deriv::PrecomputeDerivatives()
{
  Window *window = _currentWindow = (*_windows)[0]; // only one window
  ForwardDeriv();
  BackwardDeriv();
  PrepareForDerivativeComputations();
}

extern struct Cache cache;

DTYPE  Parameters_Deriv::ComputeAverageCountDerivative(int k, int alpha)
{
  int wi = 0;
  DTYPE correction = FringeCorrectionFactor(wi);
  DTYPE B = _A_d[k][alpha]*correction; // DONT PUT correction into _A_d calculations 

  int length = _currentWindow->Length();
  DTYPE D = _alpha_d[k][alpha][length-1];
#ifdef _CORRECTIONCORRECTION
  int bkgIndex = BackgroundIndex();
  WtMx **wm = new WtMx *[_numWM];
  for (int i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }
  DTYPE Dcorrection = _alpha[length-1]*correction;
  DTYPE sum = 0;
  for (int i=0; i<_numWM; i++) {
    if (i==bkgIndex || _wm_len[i]==1) continue;
    for (int k1=1; k1<_wm_len[i]; k1++) {
      if (length-k1-1 < 0) continue;
      if (_currentWindow->AmbiguousCharAt(length-1-k1+1)) continue;
      DTYPE  scale_factor = _cij[length-1-k1+1][k1-1];
      sum += _alpha_d[k][alpha][length-1-k1]*scale_factor*_pi[i]*ComputeSequenceProbability(_currentWindow,length-1-k1+1,length-1,wm[i]);
      if (i==_wmindex) 
	sum += _alpha[length-1-k1]*scale_factor*_pi[i]*ComputeSequenceProbabilityDerivative(_currentWindow,length-1-k1+1,length-1,wm[i],k,alpha);
    }
  }
  Dcorrection *= sum;
  D += Dcorrection;
  delete [] wm;
#endif
  DTYPE C = D*ComputeAverageCount(_wmindex);
  
  // fprintf(stderr,"B = %g\tC = %g\tDerivative = %g\n",B,C,B-C);
  return B - C;
}

DTYPE  Parameters_Deriv::ComputeSequenceProbabilityDerivative(Window *win, int start, int stop, WtMx *wm, int k, int alpha, bool both_orientations)
{
  if (start>stop) return 0;
  int wm_len = wm->Length();
  int ss_len = stop-start+1;
  if (ss_len > wm_len) {   // the sequence must be as long or shorter than wm.
    return 0;
  }

  char *dummyarray;
#ifdef BKG_FORWARD_ONLY 
  if (wm_len == 1) both_orientations = false;
#endif

  DTYPE  fprob = 1;
  if (ss_len < (k+1)) {    // the kth offset must be present
    fprob = 0;
  }
  else {
    char ch = win->IndexOfCharAt(start+k,dummyarray);  
    if (ch != alpha) {
      fprob = 0;
    }
    else {
      for (int i=0; i<ss_len; i++) {
	if (i==k) continue;
	char ch = win->IndexOfCharAt(start+i,dummyarray);
	fprob *= wm->Frequency(i,ch);
      }
    }
  }
  
  if (!both_orientations) {
    return fprob;
  }
  else fprob *= wm->GetForwardBias();

  DTYPE rprob = 1;
  if (ss_len < (wm_len-k)) { // the (wm_len-l-k)th offset must be present
    rprob = 0;
  }
  else {
    char ch = win->IndexOfCharAt(start+wm_len-1-k,dummyarray);  
    if (ch != 3-alpha) {
      rprob = 0;
    }
    else {
      for (int i=0; i<ss_len; i++) {
	if (wm_len-1-i==k) continue;
	char ch = win->IndexOfCharAt(start+i,dummyarray);
	if (ch >=0 && ch <= 3) {
	  rprob *= wm->Frequency(wm_len-1-i,3-ch);
	}
	else {
	  rprob *= wm->Frequency(wm_len-1-i,ch);
	}
      }
    }    
  }
  rprob *= (1-wm->GetForwardBias());
  
  return fprob+rprob;
}
