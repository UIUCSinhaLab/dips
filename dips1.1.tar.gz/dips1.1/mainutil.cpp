#include "mainutil.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/////////////////////////////////////////////////////////////////////
///// SYNOPSIS //////////////////////////////////////////////////////
///// Command-line arguments read here //////////////////////////////
/////////////////////////////////////////////////////////////////////

struct Options *ReadArguments(int &argbase, int argc, char **argv)
{
  struct Options *opt = new struct Options;
  while (argbase < argc && argv[argbase][0]=='-') {
    if (strstr(argv[argbase],"-crmfasta")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -crmfasta must be followed by a path\n");
	exit(1);
      }
      opt->crmfasta = argv[argbase];
      argbase++;
      continue;
    }    
    if (strstr(argv[argbase],"-tfexpr")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -tfexpr must be followed by a path\n");
	exit(1);
      }
      opt->tfexpr = argv[argbase];
      argbase++;
      continue;
    }    
    if (strstr(argv[argbase],"-bounds")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -bounds must be followed by a path\n");
	exit(1);
      }
      opt->tflimitsfile = argv[argbase];
      argbase++;
      continue;
    }    
    if (strstr(argv[argbase],"-crmexpr")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -crmexpr must be followed by a path\n");
	exit(1);
      }
      opt->crmexpr = argv[argbase];
      argbase++;
      continue;
    }    
    if (strstr(argv[argbase],"-len")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -len must be followed by an integer \n");
	exit(1);
      }
      opt->len = atoi(argv[argbase]);
      argbase++;
      continue;
    }    
    if (strstr(argv[argbase],"-seedwtmx")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -seedwtmx must be followed by a filename\n");
	exit(1);
      }
      opt->seedwtmx = argv[argbase];
      argbase++;
      continue;
    }    
    if (strstr(argv[argbase],"-wtmx")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -wtmx must be followed by a path\n");
	exit(1);
      }
      opt->wtmxfile = argv[argbase];
      argbase++;
      continue;
    }    
    if (strstr(argv[argbase],"-mode")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -mode must be followed by \"a\" or \"r\"\n");
	exit(1);
      }
      if (strstr(argv[argbase],"A") || strstr(argv[argbase],"a")) opt->mode = 0; else opt->mode = 1;
      argbase++;
      continue;
    }    
    if (strstr(argv[argbase],"-niter")) {
      opt->numIter = atoi(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-nsites")) {
      opt->nsites = atoi(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-prior")) {
      opt->prior = atof(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-depth")) {
      opt->depth = atoi(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-nmotif")) {
      opt->nmotif = atoi(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-positive")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -positive must be followed by a path\n");
	exit(1);
      }
      opt->positive = argv[argbase];
      argbase++;
      continue;
    }    
    if (strstr(argv[argbase],"-negative")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -negative must be followed by a path\n");
	exit(1);
      }
      opt->negative = argv[argbase];
      argbase++;
      continue;
    }    

    if (strstr(argv[argbase],"-startmotif")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -startmotif must be followed by a path\n");
	exit(1);
      }
      opt->startmotif = argv[argbase];
      argbase++;
      continue;
    }    

    if (strstr(argv[argbase],"-bkg")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -b must be followed by a file name\n");
	exit(1);
      }
      opt->bkg_file = argv[argbase];
      argbase++;
      continue;
    }

    if (strstr(argv[argbase],"-ot")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -ot must be followed by a number\n");
	exit(1);
      }
      opt->occurrence_threshold = atof(argv[argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-times")) {
      opt->print_times = true;
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-overlaps")) {
      opt->overlap_allowed = true;
      argbase++;
      continue;
    }
    printf("Error: option %s not recognized\n",argv[argbase]);
    exit(1);
  }

  return opt;
}
