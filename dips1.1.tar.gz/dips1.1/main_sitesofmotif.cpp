#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "mainutil.h"
#include "fastafile.h"
#include "sequence.h"
#include "expressiondata.h"
#include "optimize.h"
#include "wtmx.h"

// stubb requires these to be defined 
int   globalid;
WtMx *global_background;

void SitesOf_Motif(FastaFile &posseqs, WtMxCollection &wmtxs, WtMx *W, float occurrence_threshold, int numoccurrences=-1);

main (int argc, char **argv) 
{
  if (argc < 7) {
    printf("usage: %s -positive <Fasta file of CRMs that have motif> [-wtmx <File of other weight matrices>] [-bkg <background sequence fasta file>] [-seedwtmx <File of weight matrix to score>]\n",argv[0]);
    exit(1);
  }
  globalid = 0;
  global_background = NULL;  

  int argbase = 1;
  struct Options *opt = ReadArguments(argbase, argc, argv);

  // Read in the CRM sequence(s)
  FastaFile posseqs, negseqs;
  posseqs.ReadFasta(opt->positive);

  // Read in the other matrices  
  if (opt->wtmxfile == NULL) {
    system("touch dipsdummywtmx");
    opt->wtmxfile = "dipsdummywtmx";
  }
  WtMxCollection wmc(opt->wtmxfile);

  // set the background if needed
  if (opt->bkg_file != NULL) {
    Sequence *bkg_seq = new Sequence(opt->bkg_file);
    Window *bkg_window = new Window(bkg_seq,0,bkg_seq->Length()-1);
    global_background = Parameters::TrainWtMx(bkg_window);
    delete bkg_window;
    delete bkg_seq;
  }

      
  // initialize the wm to be scored
  WtMx *W;
  if (opt->seedwtmx != NULL) {
    WtMxCollection wmcseed(opt->seedwtmx);
    W = new WtMx(wmcseed.WM(0));
  }
  else {
    printf("Error: this program requires you to supply a weight matrix to tune\n");
    exit(1);
  }
   
  SitesOf_Motif(posseqs,wmc,W,opt->occurrence_threshold);
  exit(1);
}
  
void SitesOf_Motif(FastaFile &posseqs, WtMxCollection &wmtxs, WtMx *W, float occurrence_threshold, int numoccurrences)
  // shouldnt change posseqs, negseqs at all
  // can add wm to wmtxs, but must delete it afterwards
{
  // compute the total length of sequences
  int totalLength = 0;
  for (int i=0; i<posseqs.Size(); i++) {
    Sequence *seq = posseqs[i];
    totalLength += seq->Length();
  }

  // now process each sequence
  int numPos = posseqs.Size();
  for (int i=0; i<posseqs.Size(); i++) {
    // get the sequence window for the ith sequence
    Sequence *seq = posseqs[i];
    WindowIterator wi(seq);
    bool did_begin = wi.Begin(seq->Length(),10); 
    if (!did_begin || wi.End()) {
      printf("Error: Internal problems in Eta() function\n");
      exit(1);
    }    
    vector<Window *> *wl = new vector<Window *>;
    wi.CurrentWindowList(wl);

    // train with other wm's
    Parameters_H0 *param = new Parameters_H0;
    int bkgIndex = param->BackgroundIndex(&wmtxs);
    param->Initialize(wl,&wmtxs,bkgIndex);
    param->Train();
    DTYPE *priors = new DTYPE[param->NumWM()+1];
    for (int j=0; j<param->NumWM(); j++) priors[j] = param->GetParameter(j);
    delete param;

    // Adjust probabilities to include new matrix
    int wmindex = wmtxs.Add(W);

    // but the previously computed p_i's sum to 1, and now there is a
    // new matrix, which has to be given its own p_i, so we have
    // to make room for this extra p_i.
    float prior_probability;
    if (numoccurrences < 0) prior_probability = 0.01;
    else prior_probability = float(numoccurrences)/float(totalLength);
    priors[wmindex+1] = priors[wmindex];
    priors[wmindex] = prior_probability;
    priors[wmindex+1] -= priors[wmindex];
    
    // D-P again.
    param = new Parameters_H0;
    bkgIndex = param->BackgroundIndex(&wmtxs);
    param->Initialize(wl,&wmtxs,bkgIndex);
    param->SetParameters(priors);
    param->TrainWithFixedParameters();
    param->PrintOccurrences(stdout, wmindex, occurrence_threshold);
    
    // clean up
    delete [] priors;
    delete param;    
    delete (*wl)[0];
    delete wl;    
  }
}

