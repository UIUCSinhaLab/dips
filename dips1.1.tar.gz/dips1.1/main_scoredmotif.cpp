#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "mainutil.h"
#include "fastafile.h"
#include "sequence.h"
#include "expressiondata.h"
#include "optimize.h"
#include "wtmx.h"

// stubb requires these to be defined 
int   globalid;
WtMx *global_background;

DTYPE Score_DMotif(FastaFile &posseqs, FastaFile &negseqs, WtMxCollection &wmtxs, WtMx *W, float prob_occurrence=-1);

main (int argc, char **argv) 
{
  if (argc < 5) {
    printf("usage: %s -positive <Fasta file of CRMs that have motif> -negative <Fasta file of CRMs that dont have motif> [-wtmx <File of other weight matrices>] [-bkg <background sequence fasta file>] [-seedwtmx <File of weight matrix to score>] [-nsites <expected number of occurrences of motif>]\n",argv[0]);
    exit(1);
  }
  globalid = 0;
  global_background = NULL;  

  int argbase = 1;
  struct Options *opt = ReadArguments(argbase, argc, argv);

  // Read in the CRM sequence(s)
  FastaFile posseqs, negseqs;
  posseqs.ReadFasta(opt->positive);
  negseqs.ReadFasta(opt->negative);

  // Read in the other matrices  
  if (opt->wtmxfile == NULL) {
    system("touch dipsdummywtmx");
    opt->wtmxfile = "dipsdummywtmx";
  }
  WtMxCollection wmc(opt->wtmxfile);

  // set the background if needed
  if (opt->bkg_file != NULL) {
    Sequence *bkg_seq = new Sequence(opt->bkg_file);
    Window *bkg_window = new Window(bkg_seq,0,bkg_seq->Length()-1);
    global_background = Parameters::TrainWtMx(bkg_window);
    delete bkg_window;
    delete bkg_seq;
  }

      
  // initialize the wm to be scored
  WtMx *W;
  if (opt->seedwtmx != NULL) {
    WtMxCollection wmcseed(opt->seedwtmx);
    W = new WtMx(wmcseed.WM(0));
  }
  else {
    printf("Error: this program requires you to supply a weight matrix to tune\n");
    exit(1);
  }
   
  // compute the total length of positive sequences
  int totalLength = 0;
  for (int i=0; i<posseqs.Size(); i++) {
    Sequence *seq = posseqs[i];
    totalLength += seq->Length();
  }      
  
  int numOccurrences = opt->nsites;
  DTYPE score = Score_DMotif(posseqs,negseqs,wmc,W,float(numOccurrences)/float(totalLength));
  printf("Score\t%f\n",score);
  delete W;
}
  
DTYPE Score_DMotif(FastaFile &posseqs, FastaFile &negseqs, WtMxCollection &wmtxs, WtMx *W, float prob_occurrences)
  // shouldnt change posseqs, negseqs at all
  // can add wm to wmtxs, but must delete it afterwards
{
  FastaFile *seqs = new FastaFile;
  int numPos = posseqs.Size();
  for (int i=0; i<posseqs.Size(); i++) seqs->Add(posseqs[i]);
  int numNeg = negseqs.Size();
  for (int i=0; i<negseqs.Size(); i++) seqs->Add(negseqs[i]);

  // create the dummy "locations" array
  // where each location has exactly one crm expressed there
  bool **L = new bool *[seqs->Size()];
  for (int i=0; i<seqs->Size(); i++) {
    L[i] = new bool[seqs->Size()];
  }
  for (int j=0; j<numPos; j++) {
    for (int k=0; k<numPos; k++) {
      if (j==k) L[j][k] = true;
      else L[j][k] = false;
    }
    for (int k=0; k<numNeg; k++) L[j][k+numPos] = false;
  }
  for (int j=0; j<numNeg; j++) {
    for (int k=0; k<numPos; k++) L[j+numPos][k] = false;
    for (int k=0; k<numNeg; k++) {
      if (j==k) L[j+numPos][k+numPos] = true;
      else L[j+numPos][k+numPos] = false;
    }
  }

  // IMPORTANT:
  // create the dummy "expression" array
  // which simply marks the positive and negative sequences separately.
  ExpressionData *expr = new ExpressionData;
  expr->ManualInitialize(seqs->Size());
  expr->InvalidateAll();
  for (int j=0; j<numPos; j++) expr->Validate(j);

  // run steepest descent to find motif
  DTYPE score = Score(W, seqs, expr, L, &wmtxs, prob_occurrences);

  // Clean up
  delete expr;
  for (int i=0; i<seqs->Size(); i++) delete [] L[i];
  delete [] L;
  
  return score;
}

