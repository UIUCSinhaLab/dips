#ifndef _OPTIMIZE_H_
#define _OPTIMIZE_H_

#include "sequence.h"
#include "parameters.h"
#include "fastafile.h"
#include "wtmx.h"
#include "expressiondata.h"
#include "motif.h"

#define MAXITERATIONS 100
#define DEFAULT_PRIOR_PROBABILITY 0.01
#define PRECIS 1.e-3
#ifdef  _NOGRAD
#define MAXATTEMPTSTOMOVE 50000
#else
#define MAXATTEMPTSTOMOVE 500
#endif
#define MAXATTEMPTSTOBIGMOVE 100
#define NEGINF -1000000
#define WFACTOR 0.5

// the two main functions of this file
DTYPE  Optimize_SD(Motif *&motif, FastaFile *crmseqs, ExpressionData *tfexpr, bool **L, WtMxCollection *wmtxs, float prob_occurrences = -1);
DTYPE  Score(WtMx *W, FastaFile *crmseqs, ExpressionData *tfexpr, bool **L, WtMxCollection *wmtxs, float prob_occurrences=-1);

// helpers used by optimize_df()
double SD_Move(Motif *&motif, double F_cur, float temperature);
double SD_Homogenize_Move(Motif *motif, double F_cur);
double SD_Big_Move(Motif *motif, double F_old);
double EstimateDeltaFFast(int w, int *tryStr, WtMx *curWM);
void   CacheDeltaF(WtMx *curWM, Motif *motif, int wm_len);

// computation of the scores
double F(WtMx *W, bool derivatives=true);
double GradF(WtMx *W, int k, int alpha);
void   TrainOnCRM(int i, bool derivatives=true);

#endif
