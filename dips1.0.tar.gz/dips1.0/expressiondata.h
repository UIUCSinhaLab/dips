#ifndef _EXPRDATA_H_
#define _EXPRDATA_H_

class ExpressionData {
  int _L;
  float *_expr;
  float *_dexpr; // discretized and normalized expression
  bool _inverted;
  bool  *_valid;
  
 public:
  static const float RESOLN = 0.01;

  ExpressionData();
  ExpressionData(char *flname, char *tag = NULL);
  ~ExpressionData();

  int getL();
  void Invert();
  float operator[] (int index);  // returns dexpr[]
  void InvalidateAll();
  void Validate(int j);
  bool IsValid(int j);
  void ManualInitialize(int L);
  float MaxExpression();         // over dexpr[]
};

#endif
