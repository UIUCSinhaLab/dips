#ifndef _GIBBS_H_
#define _GIBBS_H_

#include <stdio.h>
#include "sequence.h"

#define MAXSITES 1000

class Motif {
  struct substringspecs {
    int _seqindex;
    int _offset;
    bool _reverse;
    bool _valid;
    substringspecs() { _valid = false; _reverse = false; }
  };
  struct substringspecs _pairs[MAXSITES];
  int _numValid;
  Sequence *_seqs[MAXSITES];
  int _numSequences;
  int _motifLength;
  static const float _pseudo_count = 0.01;

public:
  Motif();
  int  Size();
  void Print(FILE *fp = stdout);

  // methods to add or delete motifs
  int  Add(int seq, int offset, bool reverse=false);
  void Delete(int index);
  void Undelete(int index);
  int  GetNthValidIndex(int n); 
  void Clear(); // invalidate all

  // methods to query the motif for the site that has a particular index (id)
  int  GetSequenceIndex(int index);
  int  GetOffset(int index);
  bool IsReverse(int index);
  void GetSite(int i, char *&str);

  // method  to query the motif for the site that has a particular specs.
  void GetSiteAsIndices(int seqindex, int seqoffset, bool orient_reverse, int *&str);

  // methods to manipulate the sequences associated with the motif
  void AddSequence(Sequence *seq);
  Sequence *GetSequence(int index);
  int  NumSequences();

  void SetMotifLength(int w);
  int  GetMotifLength();
  WtMx *ConstructWtMx();
  bool OverlapsSomeSiteOrHasN(int s, int o);
  bool HasN(int s, int o);

  // computes the delta vector for column wm_offset, if a character
  // chindex is added to that column in curWM.
  float *ComputeDeltaVector(int chindex, int wm_offset, WtMx *curWM);

  static void ReverseComplement(char *t, char *s);

};
   


#endif
