#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "mainutil.h"
#include "fastafile.h"
#include "sequence.h"
#include "expressiondata.h"
#include "optimize.h"

// stubb requires these to be defined 
int   globalid;
WtMx *global_background;

// global for printing progress of times
extern bool print_times;
//global for determining if overlapping or identical sites are allowed in motif
extern bool overlap_allowed;

// functions used by this file
DTYPE Find_DMotif(FastaFile &posseqs, FastaFile &negseqs, WtMxCollection &wmtxs, Motif *&m, float prob_occurrences);
void SitesOf_Motif(FastaFile &posseqs, WtMxCollection &wmtxs, WtMx *W, float occurrence_threshold, float prob_occurrences);



main (int argc, char **argv) 
{
  if (argc < 5) {
    printf("usage: %s -positive <Fasta file of CRMs that have motif> -negative <Fasta file of CRMs that dont have motif> -len <Motif Length> [-wtmx <File of other weight matrices>] [-nsites <expected number of occurrences of motif>] [-prior <expected number of occurrences of motif per base pair of positive sequences>] [-depth <number of substrings in the alignment that'll be reported>] [-bkg <background sequence fasta file>] [-niter <number of seeds that'll be tried>] [-nmotif <number of motifs that'll be reported, using masking of each reported motif>] \n",argv[0]);
    exit(1);
  }
  globalid = 0;
  global_background = NULL;  

  int argbase = 1;
  struct Options *opt = ReadArguments(argbase, argc, argv);
  print_times = opt->print_times;
  overlap_allowed = opt->overlap_allowed;

  // Read in the CRM sequence(s)
  FastaFile posseqs, negseqs;
  posseqs.ReadFasta(opt->positive);
  negseqs.ReadFasta(opt->negative);

  // the motif length;
  int w = opt->len;
  if (w < 1) {
    printf("Cant look for motif of length less than 1\n");
    printf("Please use the -len option\n");
    exit(1);
  }
  
  // Read in the other matrices  
  if (opt->wtmxfile == NULL) {
    system("touch dipsdummywtmx");
    opt->wtmxfile = "dipsdummywtmx";
  }
  WtMxCollection wmc(opt->wtmxfile);

  // set the background if needed
  if (opt->bkg_file != NULL) {
    Sequence *bkg_seq = new Sequence(opt->bkg_file);
    Window *bkg_window = new Window(bkg_seq,0,bkg_seq->Length()-1);
    global_background = Parameters::TrainWtMx(bkg_window);
    delete bkg_window;
    delete bkg_seq;
  }

  // compute the total length of positive sequences
  int totalLength = 0;
  for (int i=0; i<posseqs.Size(); i++) {
    Sequence *seq = posseqs[i];
    totalLength += seq->Length();
  }      

  // find as many motifs as specified by opt->nmotif
  for (int motifcount=0; motifcount < opt->nmotif; motifcount++) {
    // iterate over many seeds, converge from each, and choose best.
    DTYPE best_score = -10000; int best_seed = 0;
    Motif best_motif;
    
    for (int iter=1; iter <= opt->numIter; iter++) {
      fprintf(stderr,"New seeding %d\n",iter);
      srand(iter);
      
      // create initial set of sites
      int numSites = opt->depth;
      // if not user-specified, find one per input (positive) sequence
      if (numSites <= 0) numSites = posseqs.Size();
      // create the Motif object with initial choice of sites
      Motif *motif = new Motif;
      // first add all the sequences where the search will happen
      for (int i=0; i<posseqs.Size(); i++) motif->AddSequence(posseqs[i]);
      // and add the sites as substrings of these sequences
      if (opt->startmotif) { // the starting motif is specified in a file
	FILE *sm = fopen(opt->startmotif,"r");
	int numSitesRead = 0;
	char line[1024];
	while (fgets(line,1023,sm)) {
	  char mot[1024];
	  int seqindex, offset, orient;
	  sscanf(line,"%s\t(%d,%d,%d)",mot,&seqindex, &offset, &orient);
	  motif->Add(seqindex, offset, orient==1);
	  numSitesRead ++;
	}
	fclose(sm);
	numSites = numSitesRead;
      }
      else { // choose a random alignment as starting motif
	for (int i=0,j=0; i<numSites && j<1000; j++) {
	  Sequence *siteseq = posseqs[i%posseqs.Size()];
	  int sitelength = siteseq->Length();
	  if (sitelength < w) {
	    continue;
	  }
	  // choose a random position between 0 and sitelength-w
	  int r = rand()%(sitelength-w+1);
	  // make sure there is no N in the chosen site
	  bool Nfound = false;
	  for (int l=0; l<w; l++) {
	    int posn = r + l;
	    int indexofcharat = siteseq->IndexOfCharAt(posn);
	    if (indexofcharat < 0 || indexofcharat > 3) {
	      Nfound = true;
	      break;
	    }
	  }
	  if (Nfound) continue;
	  // insert element (i,r) into the motif
	  motif->Add(i%posseqs.Size(),r);                
	  i++;
	}
      }

      // now start the Optimizer 
      motif->SetMotifLength(w);
      float numOccurrences = opt->nsites;
      if (numOccurrences < 0) numOccurrences = totalLength*opt->prior;
      DTYPE score = Find_DMotif(posseqs,negseqs,wmc,motif,float(numOccurrences)/float(totalLength));
      if (score > best_score) {
	best_seed = iter;
	best_score = score;
	best_motif = *motif;
      }
      fprintf(stderr,"End seeding %d\n\n\n\n",iter);
    }
  
    // output the best motif
    printf("Motif %d Score %f\n",motifcount+1,best_score);
    WtMx *wm = best_motif.ConstructWtMx();
    wm->Print();
    printf("## Sites in motif\n");
    best_motif.Print();
    printf("##\n");
    printf("## Occurrences above threshold %f\n",opt->occurrence_threshold);
    fflush(stdout);
    float numOccurrences = opt->nsites;
    if (numOccurrences < 0) numOccurrences = totalLength*opt->prior;
    SitesOf_Motif(posseqs,wmc,wm,opt->occurrence_threshold,float(numOccurrences)/float(totalLength));
    fflush(stdout);
    printf("##\n");
#ifdef _DO_MASK_
    delete wm;
    
    // mask this motif out
    for (int i=0; i<best_motif.Size(); i++) {
      int mindex = best_motif.GetNthValidIndex(i);
      int sindex = best_motif.GetSequenceIndex(mindex);
      Sequence *siteseq = best_motif.GetSequence(sindex);
      int l = best_motif.GetOffset(mindex);
#ifndef _MASK_ALL_
      int posl = l + (int)(w/2);
      int posr = l + (int)ceilf(w/2);
      for (int pos=posl; pos <= posr; pos++) {
	siteseq->Mask(pos);
      }
#else
      for (int pos=l; (pos < l+_wm_len[wmi]) && (pos < siteseq->Length()); pos++) {
	siteseq->Mask(pos);
      }	  
#endif      
    }
#else
      wmc.Add(wm);
#endif
  }
}
  
DTYPE Find_DMotif(FastaFile &posseqs, FastaFile &negseqs, WtMxCollection &wmtxs, Motif *&m, float prob_occurrences)
  // shouldnt change posseqs, negseqs at all
  // can add wm to wmtxs, but must delete it afterwards
  // can (will) change m
{
  FastaFile *seqs = new FastaFile;
  int numPos = posseqs.Size();
  for (int i=0; i<posseqs.Size(); i++) seqs->Add(posseqs[i]);
  int numNeg = negseqs.Size();
  for (int i=0; i<negseqs.Size(); i++) seqs->Add(negseqs[i]);

  // create the dummy "locations" array
  // where each location has exactly one crm expressed there
  bool **L = new bool *[seqs->Size()];
  for (int i=0; i<seqs->Size(); i++) {
    L[i] = new bool[seqs->Size()];
  }
  for (int j=0; j<numPos; j++) {
    for (int k=0; k<numPos; k++) {
      if (j==k) L[j][k] = true;
      else L[j][k] = false;
    }
    for (int k=0; k<numNeg; k++) L[j][k+numPos] = false;
  }
  for (int j=0; j<numNeg; j++) {
    for (int k=0; k<numPos; k++) L[j+numPos][k] = false;
    for (int k=0; k<numNeg; k++) {
      if (j==k) L[j+numPos][k+numPos] = true;
      else L[j+numPos][k+numPos] = false;
    }
  }

  // IMPORTANT:
  // create the dummy "expression" array
  // which simply marks the positive and negative sequences separately.
  ExpressionData *expr = new ExpressionData;
  expr->ManualInitialize(seqs->Size());
  expr->InvalidateAll();
  for (int j=0; j<numPos; j++) expr->Validate(j);

  // run steepest descent to find motif
  // since nsites is not provided as argument, the prior probability
  // will be fixed at 0.01.
  DTYPE score = Optimize_SD(m, seqs, expr, L, &wmtxs, prob_occurrences);
  fprintf(stderr,"SEED ITERATION (SD) GAVE SCORE %g with motif:\n",score);
  m->Print(stderr);  

#ifdef _SDFOLLOWEDBYCG
  // then run conjugate gradient to tune motif
  WtMx *W = m->ConstructWtMx();
  DTYPE score = Optimize_CG(W, seqs, expr, L, &wmtxs);
  fprintf(stderr,"SEED ITERATION (CG) GAVE SCORE %g with motif:\n",score);
  W->Print(stderr);
  delete W;
#endif

  // Clean up
  delete expr;
  for (int i=0; i<seqs->Size(); i++) delete [] L[i];
  delete [] L;
  
  return score;
}

void SitesOf_Motif(FastaFile &posseqs, WtMxCollection &wmtxs, WtMx *W, float occurrence_threshold, float prob_occurrences)
  // shouldnt change posseqs, negseqs at all
  // can add wm to wmtxs, but must delete it afterwards
{
  // compute the total length of sequences
  int totalLength = 0;
  for (int i=0; i<posseqs.Size(); i++) {
    Sequence *seq = posseqs[i];
    totalLength += seq->Length();
  }

  // now process each sequence
  int r = rand();
  char occfile[1024];
  sprintf(occfile,"occurrences_%d.txt",r);
  char command[1024];
  sprintf(command,"rm %s",occfile);
  system(command);
  int numPos = posseqs.Size();
  for (int i=0; i<posseqs.Size(); i++) {
    // get the sequence window for the ith sequence
    Sequence *seq = posseqs[i];
    WindowIterator wi(seq);
    bool did_begin = wi.Begin(seq->Length(),10); 
    if (!did_begin || wi.End()) {
      printf("Error: Internal problems in Eta() function\n");
      exit(1);
    }    
    vector<Window *> *wl = new vector<Window *>;
    wi.CurrentWindowList(wl);

    // train with other wm's
    Parameters_H0 *param = new Parameters_H0;
    int bkgIndex = param->BackgroundIndex(&wmtxs);
    param->Initialize(wl,&wmtxs,bkgIndex);
    param->Train();
    DTYPE *priors = new DTYPE[param->NumWM()+1];
    for (int j=0; j<param->NumWM(); j++) priors[j] = param->GetParameter(j);
    delete param;

    // Adjust probabilities to include new matrix
    int wmindex = wmtxs.Add(W);

    // but the previously computed p_i's sum to 1, and now there is a
    // new matrix, which has to be given its own p_i, so we have
    // to make room for this extra p_i.
    float prior_probability;
    if (prob_occurrences < 0) {
      fprintf(stderr,"Error in SitesOf_Motif\n");
      exit(1);
    }
    else {
      prior_probability = prob_occurrences;
      priors[wmindex+1] = priors[wmindex];
      priors[wmindex] = prior_probability;
      priors[wmindex+1] -= priors[wmindex];
    }
    
    // D-P again.
    param = new Parameters_H0;
    bkgIndex = param->BackgroundIndex(&wmtxs);
    param->Initialize(wl,&wmtxs,bkgIndex);
    param->SetParameters(priors);
    param->TrainWithFixedParameters();
    FILE *tmpfp = fopen(occfile,"a");
    param->PrintOccurrences(tmpfp, wmindex, occurrence_threshold);
    fclose(tmpfp);
    
    // clean up
    wmtxs.Remove(wmindex);
    delete [] priors;
    delete param;    
    delete (*wl)[0];
    delete wl;    
  }
  sprintf(command,"sort -n -k 6 -r %s",occfile);
  system(command);
  sprintf(command,"rm %s",occfile);
  system(command);
}

