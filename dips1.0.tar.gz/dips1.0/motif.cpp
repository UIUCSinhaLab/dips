#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "motif.h"

/////////////////////////////////////////////////////////////////////
///// SYNOPSIS //////////////////////////////////////////////////////
///// the Motif class : stores the sequences over which /////////////
///// the motif is defined. The motif is a set of substrings ////////
///// (seqindex, seqoffset, orient_reverse) of these sequences //////
/////////////////////////////////////////////////////////////////////

int Motif::Size() 
{
  return _numValid;
}

int Motif::GetNthValidIndex(int n)
{
  if (n >= _numValid) {
    printf("Error: GetNthValidIndex called with invalid argument\n");
    exit(1);
  }

  int count = 0;
  for (int i=0; i<MAXSITES; i++) {
    if (!_pairs[i]._valid) continue;
    if (count == n) return i;
    count++;
  }
}

int Motif::GetSequenceIndex(int index)
{
  return _pairs[index]._seqindex;
}

int Motif::GetOffset(int index)
{
  return _pairs[index]._offset;
}

bool Motif::IsReverse(int index)
{
  return _pairs[index]._reverse;
}

void Motif::Clear()
{
  for (int i=0; i<MAXSITES; i++) {
    if (_pairs[i]._valid) _numValid--;      
    _pairs[i]._valid = false;
  }
}

void Motif::Delete(int index)
{
  if (_pairs[index]._valid) _numValid--;
  _pairs[index]._valid = false;
}

void Motif::Undelete(int index)
{
  if (_pairs[index]._valid) {
    printf("Error: undelete called on an undeleted site\n");
    exit(1);
  }
  _pairs[index]._valid = true;
  _numValid++;
}

int Motif::Add(int seq, int offset, bool reverse)
{
  for (int i=0; i<MAXSITES; i++) {
    if (!_pairs[i]._valid) {
      _pairs[i]._seqindex = seq;
      _pairs[i]._offset = offset;
      _pairs[i]._valid = true;
      _pairs[i]._reverse = reverse;
      _numValid++;
      return i;
    }
  }
  printf("Error: Motif full, couldnt add %d %d\n",seq,offset);
}

void Motif::AddSequence(Sequence *seq)
{
  _seqs[_numSequences++] = seq;
}

Sequence *Motif::GetSequence(int index)
{
  return _seqs[index];
}

int Motif::NumSequences()
{
  return _numSequences;
}

void Motif::SetMotifLength(int w)
{
  _motifLength = w;
}

int Motif::GetMotifLength()
{
  return _motifLength;
}

Motif::Motif()
{
  for (int i=0; i<MAXSITES; i++) _seqs[i] = NULL;
  _numSequences = 0;
  _numValid = 0;
}

WtMx *Motif::ConstructWtMx()
{
  int wmlength = _motifLength;
  float **w = new float *[4];
  for (int i=0; i<4; i++) {
    w[i] = new float[wmlength];
    for (int j=0; j<wmlength; j++) w[i][j] = 0;
  }
  for (int i=0; i<MAXSITES; i++) {
    if (!_pairs[i]._valid) continue;
    int s = _pairs[i]._seqindex;
    Sequence *seq = _seqs[s];
    int o = _pairs[i]._offset;
    for (int l=0; l<wmlength; l++) {
      int posn = o+l;
      int charat = seq->IndexOfCharAt(posn);
      if (charat < 0 || charat > 4) { 
	printf("Error: found invalid character\n");
	exit(1);
      }
      if (charat == 4) { // ambiguous char
	for (int j=0; j<4; j++) 
	  if (!_pairs[i]._reverse) 
	    w[j][l] += 0.25;
	  else 
	    w[j][wmlength-1-l] += 0.25;
      }
      else {
	if (!_pairs[i]._reverse) 
	  w[charat][l] += 1.0;
	else 
	  w[3-charat][wmlength-1-l] += 1.0;
      }
    }
  }
  // normalize with pseudocounts
  for (int i=0; i<wmlength; i++) {
    float sum = 0;
    for (int j=0; j<4; j++) {
      sum += w[j][i];
    }
    for (int j=0; j<4; j++) {
      w[j][i] = (w[j][i] + _pseudo_count)/(sum+4*_pseudo_count);
    }
  }

  WtMx *WM = new WtMx(w,wmlength,"motif",0); // no pseudocounts again !
  for (int i=0; i<4; i++) {
    delete [] w[i];
  }
  delete [] w;
  return WM;
}

float *Motif::ComputeDeltaVector(int chindex, int wm_offset, WtMx *curWM)
{
  int wmlength = _motifLength;
  float **w = new float *[4];
  for (int i=0; i<4; i++) {
    w[i] = new float[wmlength];
    for (int j=0; j<wmlength; j++) w[i][j] = 0;
  }
  for (int i=0; i<MAXSITES; i++) {
    if (!_pairs[i]._valid) continue;
    int s = _pairs[i]._seqindex;
    Sequence *seq = _seqs[s];
    int o = _pairs[i]._offset;
    for (int l=0; l<wmlength; l++) {
      int posn = o+l;
      int charat = seq->IndexOfCharAt(posn);
      if (charat < 0 || charat > 4) { 
	printf("Error: found invalid character\n");
	exit(1);
      }
      if (charat == 4) { // ambiguous char
	for (int j=0; j<4; j++) 
	  if (!_pairs[i]._reverse) 
	    w[j][l] += 0.25;
	  else 
	    w[j][wmlength-1-l] += 0.25;
      }
      else {
	if (!_pairs[i]._reverse) 
	  w[charat][l] += 1.0;
	else 
	  w[3-charat][wmlength-1-l] += 1.0;
      }
    }
  }
  
  // increment count for column wm_offset
  w[chindex][wm_offset] += 1.0;

  // normalize with pseudocounts
  for (int i=0; i<wmlength; i++) {
    float sum = 0;
    for (int j=0; j<4; j++) {
      sum += w[j][i];
    }
    for (int j=0; j<4; j++) {
      w[j][i] = (w[j][i] + _pseudo_count)/(sum+4*_pseudo_count);
    }
  }

  // already computed the new w; now compute the delta
  float *delta = new float[4];
  for (int i=0; i<4; i++) {
    delta[i] = w[i][wm_offset] - curWM->Frequency(wm_offset,i);
  }

  // Clean up
  for (int i=0; i<4; i++) {
    delete [] w[i];
  }
  delete [] w;

  return delta;
}

bool Motif::OverlapsSomeSiteOrHasN(int s, int o)
{
  for (int i=0; i<MAXSITES; i++) {
    if (!_pairs[i]._valid) continue;
    if (_pairs[i]._seqindex != s) continue;
    int diff = _pairs[i]._offset - o;
    if (diff < 0) diff = -diff;
    if (diff < _motifLength) return true;
  }

  bool Nfound = false;
  Sequence *siteseq = GetSequence(s);
  int w = _motifLength;
  for (int l=0; l<w; l++) {
    int posn = o + l;
    if (posn >= siteseq->Length()) 
      return true;
    int indexofcharat = siteseq->IndexOfCharAt(posn);
    if (indexofcharat < 0 || indexofcharat > 3) {
      return true;
    }
  }
  return false;
}

bool Motif::HasN(int s, int o)
{
  bool Nfound = false;
  Sequence *siteseq = GetSequence(s);
  int w = _motifLength;
  for (int l=0; l<w; l++) {
    int posn = o + l;
    if (posn >= siteseq->Length()) 
      return true;
    int indexofcharat = siteseq->IndexOfCharAt(posn);
    if (indexofcharat < 0 || indexofcharat > 3) {
      return true;
    }
  }
  return false;
}

void Motif::GetSite(int i, char *&str) 
{
  if (str == NULL) str = new char[_motifLength+1];
  int s = _pairs[i]._seqindex;
  Sequence *seq = _seqs[s];
  int o = _pairs[i]._offset;
  for (int l=0; l<_motifLength; l++) {
    int posn = o+l;
    int charat = seq->CharAt(posn);
    str[l] = charat;
  }
  str[_motifLength] = 0;
  char reverse[1024];
  if (_pairs[i]._reverse) {
    ReverseComplement(reverse,str);
    strcpy(str,reverse);
  }
}

void Motif::GetSiteAsIndices(int seqindex, int seqoffset, bool orient_reverse, int *&str) 
{
  if (str == NULL) str = new int[_motifLength+1];
  int s = seqindex;
  Sequence *seq = _seqs[s];
  int o = seqoffset;
  for (int l=0; l<_motifLength; l++) {
    int posn = o+l;
    int indexofcharat = seq->IndexOfCharAt(posn);
    str[l] = indexofcharat;
  }
  str[_motifLength] = 0;

  int reverse[1024];
  if (orient_reverse) {    
    for (int j=0; j<_motifLength; j++) {
      if (str[j] > 3 || str[j] < 0) {
	printf("Error: invalid character in motif candidate\n");
	exit(1);
      }
      reverse[_motifLength-1-j] = 3-str[j];
    }
    for (int j=0; j<_motifLength; j++) str[j] = reverse[j];
  }
}



void Motif::Print(FILE *fp)
{
  char *str = new char[1024];
  for (int i=0; i<MAXSITES; i++) {
    if (!_pairs[i]._valid) continue;
    int s = _pairs[i]._seqindex;
    int o = _pairs[i]._offset;
    GetSite(i,str);
    fprintf(fp,"%s\t(%d,%d,%d)\n",str,s,o,(_pairs[i]._reverse?1:0));
  }
  delete [] str;
  return;
}

void Motif::ReverseComplement(char *t, char *s)
{
  int length = strlen(s);
  for (int i=0; i<length; i++) {
    char ch = s[i];
    char tch = 'N';
    switch(ch) {
    case 'A': tch = 'T'; break;
    case 'a': tch = 't'; break;
    case 'C': tch = 'G'; break;
    case 'c': tch = 'g'; break;
    case 'G': tch = 'C'; break;
    case 'g': tch = 'c'; break;
    case 'T': tch = 'A'; break;
    case 't': tch = 'a'; break;
    case 'N': tch = 'N'; break;
    case 'n': tch = 'n'; break;
    }
    t[length-1-i] = tch;
  }
  t[length] = 0;
  return;
}
