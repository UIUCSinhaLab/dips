#ifndef _UTIL_H_
#define _UTIL_H_

#include <stdio.h>

struct Options {
  char *crmfasta;
  char *tfexpr;
  char *tflimitsfile;
  char *crmexpr;
  char *wtmxfile;
  char *seedwtmx;
  int   len;
  int   mode;
  int   numIter;
  char *positive;
  char *negative;
  int   nsites;
  float prior;
  int   depth;
  int   nmotif;
  char *startmotif;
  char *bkg_file;
  float occurrence_threshold;
  bool  print_times;
  bool overlap_allowed;

  Options() { crmfasta = tfexpr = crmexpr = wtmxfile = positive = negative = NULL; seedwtmx = NULL; len = 0; mode = 0; tflimitsfile = NULL; numIter = 5; nsites = -1; prior = 0.0025; depth = 20; nmotif = 1; startmotif = NULL; bkg_file = NULL; occurrence_threshold = 0.5; print_times = false; overlap_allowed = false; }
};

struct Options *ReadArguments(int &argbase, int argc, char **argv);

#endif
