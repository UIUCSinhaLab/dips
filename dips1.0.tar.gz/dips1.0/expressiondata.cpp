#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "expressiondata.h"

/////////////////////////////////////////////////////////////////////
///// SYNOPSIS //////////////////////////////////////////////////////
///// An object of this class encapsulates the expression profile ///
///// of the TF whose motif is being searched. //////////////////////
/////////////////////////////////////////////////////////////////////

ExpressionData::ExpressionData()
{
  _L = 0;
  _expr = _dexpr = NULL;
  _inverted = false;
  _valid = NULL;
}

void ExpressionData::ManualInitialize(int L)
{
  _L = L;
  _expr = new float[_L];
  _dexpr = new float[_L];
  _valid = new bool[_L];
}

ExpressionData::ExpressionData(char *flname, char *tag)
{
  FILE *fp = fopen(flname,"r");
  char line[1024];

  // first read the number of intervals for which we have values
  if (tag == NULL) {
    // if no tag provided, then file has a single list of expression values
    fgets(line,1023,fp);
    int num;
    sscanf(line,"%d",&num);
    _L = num;
  }
  else {
    // find the line that has the tag; the same line has _L
    while (fgets(line,1023,fp)) {
      if (strstr(line,tag)) {
	int num;
	sscanf(line,"%d",&num);
	_L = num;
	break;
      }
    }
  }

  // read in the values
  _expr = new float[_L];
  _valid = new bool[_L];
  for (int i=0; i<_L; i++) {
    fgets(line,1023,fp);
    float fnum;
    sscanf(line,"%f",&fnum);
    _expr[i] = fnum;
    _valid[i] = true;
  }

  // normalize
  float max = -1;
  _dexpr = new float[_L];
#ifdef _NORMALIZETFEXPRESSION
  for (int i=0; i<_L; i++) {
    if (_expr[i] < 0) { printf("Error: Negative expression values not allowed\n"); exit(1); }
    if (_expr[i] > max) { max = _expr[i]; }
  }
#else
  max = 1;
#endif
  for (int i=0; i<_L; i++) {
    _dexpr[i] = _expr[i]/max;
  }

  // discretize
#ifdef _DISCRETIZETFEXPRESSION
  for (int i=0; i<_L; i++) {
    int discr = int(floor(_dexpr[i]/RESOLN));
    _dexpr[i] = discr*RESOLN;
  }
#endif
}

ExpressionData::~ExpressionData()
{
  if (_expr) delete [] _expr;
  _expr = NULL;
  if (_dexpr) delete [] _dexpr;
  _dexpr = NULL;
  if (_valid) delete [] _valid;
  _valid = NULL;
}
  
int ExpressionData::getL()
{
  return _L;
}

void ExpressionData::Invert()
{
#ifdef _NORMALIZETFEXPRESSION
  for (int i=0; i<_L; i++) {
    _dexpr[i] = 1-_dexpr[i];
  }
  _inverted = true;
#else
  fprintf(stderr,"Error: Invert() called on ExpressionData without prior normalization\n");
  exit(1);
#endif
}

float ExpressionData::operator[] (int index)
{
  return _dexpr[index];
}

void ExpressionData::InvalidateAll()
{
  for (int i=0; i<_L; i++) _valid[i] = false;
}

void ExpressionData::Validate(int j)
{
  _valid[j] = true;
}
	
bool ExpressionData::IsValid(int j)
{
  return _valid[j];
}

float ExpressionData::MaxExpression()
{
  float max = 1;
  for (int i=0; i<_L; i++) {
    if (_dexpr[i] > max) max = _dexpr[i];
  }
  return max;
}
