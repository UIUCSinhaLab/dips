#ifndef _parameters_deriv_h_
#define _parameters_deriv_h_

#include "parameters.h"

class Parameters_Deriv : public Parameters_H0 {
  DTYPE  ***_alpha_d;                // forward  variables derivatives
  DTYPE  ***_beta_d;                 // backward variables derivatives 
  DTYPE  **_A_d;
  DTYPE  ***_Al_d_window;
  int       _wmindex;

 public:
  Parameters_Deriv();
  ~Parameters_Deriv();
  Parameters_Deriv(const Parameters_Deriv &p);               
  // copy constructor
  Parameters_Deriv& operator=(const Parameters_Deriv &p);    
  // assignment operator

  void SetFreeWMIndex(int wmi);      // this also creates space for  _alpha_d and _beta_d

  void ForwardDeriv();               // alpha_d and
  void BackwardDeriv();              // beta_d calculated in the process
  void PrepareForDerivativeComputations();// _A_d computed here
  void PrecomputeDerivatives();      // calls the above three functions
  DTYPE ComputeAverageCountDerivative(int k, int alpha); // actually computes derivatives

  static DTYPE  ComputeSequenceProbabilityDerivative(Window *win, int start, int stop, WtMx *wm, int k, int alpha, bool both_orientations=DEFAULT_BOTH_ORIENTATIONS);


 private:
  void   Copy(const Parameters_Deriv &p);// helper member for copy constructor and assignment operator
  void Destroy();

};

#endif
