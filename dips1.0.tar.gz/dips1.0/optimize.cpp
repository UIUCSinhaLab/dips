#include <stdio.h>
#include <assert.h>
#include <math.h>
#ifdef _DEBUG
#include <sys/time.h>
#endif

#include "optimize.h"
#include "sequence.h"
#include "parameters.h"
#include "fastafile.h"
#include "parameters_deriv.h"
#include "parameters_cache.h"

// global variables, input as well as parameters
static FastaFile *crms;        // all crms
static ExpressionData *expr;   // Expression values of TF's
static bool **locations;       // 0/1 location data for CRM's
static WtMxCollection *wmc;    // all weight matrices, including the one to be trained
static int wmindex;            // Index of the trained wm in wmc
static Motif *motif;           // Set of sites currently forming the weight matrix, if doing a SD optimization

// cache where parameters are stored
static struct Cache *cache;

// globals exported
bool print_times;
bool overlap_allowed;

#ifdef _DEBUGCC
// globals for debugging 
float globalXj[10000];
float globalYj[10000];
#endif

// Function to score a given wtmx W

DTYPE Score(WtMx *W, FastaFile *crmseqs, ExpressionData *tfexpr, bool **L, WtMxCollection *wmtxs, float prob_occurrences)
  // prob_occurrences should be fractional number of sites expected in the positive sequences
  // if its < 0, then prior_probability is chosen so as to have equal likelihood for background
{
  crms = crmseqs;
  expr = tfexpr;
  locations = L;
  wmc = wmtxs;
  cache = new struct Cache;
  cache->Initialize(crms->Size(),W->Length());
  
  // before working on the new motif, compute the p_is for the 
  // other input matrices; and store them in the global cache
  
  cache->usepriors = false;
  wmindex = -1;
  for (int i=0; i<crms->Size(); i++) {    
    TrainOnCRM(i,false); // no need to compute derivatives at this stage
    // this stores the computed p_is in the cache.
  }
  
  wmindex = wmc->Add(W); // now the bkgIndex will change
  // and cache the subsequence probabilities
  for (int i=0; i<crms->Size(); i++) {
    Parameters::CacheSubsequenceProbabilities((*crms)[i],wmc,0,(*crms)[i]->Length());
  }

  // but the previously computed p_i's sum to 1, and now there is a
  // new matrix, which has to be given its own p_i, so we have
  // to make room for this extra p_i.
  float prior_probability;
  if (prob_occurrences < 0) {
    prior_probability = -1; // this will be examined in AdjustPriorsForNewWtmx, and a suitable prior assigned.
  }
  else prior_probability = prob_occurrences;
  cache->AdjustPriorsForNewWtMx(wmindex,prior_probability); // accounts for change of bkgIndex
  cache->trainfreewmandbkgonly = true; // from now on, only this wtmx's and bkg's p_i is trained, if at all
  cache->usepriors = true; // from now on, no training of priors will happen.

  DTYPE score = -F(W);
  // cache->PrintCounts(stderr);
#ifdef _CORRELATIONCOEFFICIENT  
#ifdef _DEBUGCC
  FILE *fp = fopen("/tmp/plotdmotif.txt","w");
  for (int j=0; j<expr->getL(); j++) {
    fprintf(stderr,"%.3f\t%.3f\n",10*globalXj[j],5*globalYj[j]);
    fprintf(fp,"%d\t%.3f\t%.3f\n",j,10*globalXj[j],5*globalYj[j]);
  }
  fclose(fp);
  system("gnuplot helpers/wrap_gnuplot.plt");
  system("ggv /tmp/plotdmotif.ps &");
#endif
#endif
  cache->Destroy();
  for (int i=0; i<crms->Size(); i++) {
    Parameters::DeleteCacheSubsequenceProbabilities((*crms)[i]);
  }
  wmc->Remove(wmindex);

  delete cache;
  return score;
}

DTYPE Optimize_SD(Motif *&motif, FastaFile *crmseqs, ExpressionData *tfexpr, bool **L, WtMxCollection *wmtxs, float prob_occurrences)
  // prob_occurrences should be fractional number of sites expected in the positive sequences
  // if its < 0, then prior_probability is chosen so as to have equal likelihood for background
{
  // set the global variables before proceeding
  crms = crmseqs;
  expr = tfexpr;
  locations = L;
  wmc = wmtxs;
  cache = new struct Cache;
  cache->Initialize(crms->Size(),motif->GetMotifLength());
  
  // before working on the new motif, compute the p_is for the 
  // other input matrices; and store them in the global cache
  
  cache->usepriors = false;
  wmindex = -1;
  for (int i=0; i<crms->Size(); i++) {    
    TrainOnCRM(i,false); // no need to compute derivatives at this stage
    // this stores the computed p_is in the cache.
  }
  
  // construct a dummy weight matrix of correct length
  int w = motif->GetMotifLength();
  float **wm = new float *[4];
  for (int i=0; i<4; i++) {
    wm[i] = new float[w];
    for (int j=0; j<w; j++) 
      wm[i][j] = 0.25;
  }
  WtMx *W;
  W = new WtMx(wm,w,"motif",0);
  for (int i=0; i<4; i++) delete [] wm[i];
  delete [] wm;

  // and add it to wmc, updating the wmindex in the process.
  // since both are global variables, we may update the weight matrix later
  // this wtmx doesnt have to be deleted.
  wmindex = wmc->Add(W); 
  // and cache the subsequence probabilities
  for (int i=0; i<crms->Size(); i++) {
    Parameters::CacheSubsequenceProbabilities((*crms)[i],wmc,0,(*crms)[i]->Length());
  }
  W->SetUserData(-1); // dont use caches probabilities for W
    

  // but the previously computed p_i's sum to 1, and now there is a
  // new matrix, which has to be given its own p_i, so we have
  // to make room for this extra p_i.
  int totalLength = 0;
  for (int i=0; i<motif->NumSequences(); i++) {
    Sequence *seq = motif->GetSequence(i);
    totalLength += seq->Length();
  }
  float prior_probability;
  if (prob_occurrences < 0) {
    prior_probability = -1; // this will be examined in AdjustPriorsForNewWtmx, and a suitable prior assigned.
  }
  else prior_probability = prob_occurrences;
  cache->AdjustPriorsForNewWtMx(wmindex,prior_probability);
  cache->trainfreewmandbkgonly = true; // from now on, only this wtmx's and bkg's p_i is trained, if at all
  cache->usepriors = true; // from now on, no training of priors will happen

  // now iterate 
  int numIterations = 0;
  double F_curr = NEGINF;

  time_t start_time = time(NULL);
  while (numIterations < MAXITERATIONS) {
    fprintf(stderr,"****************** SD iteration %d\n",numIterations);
    double F_new = SD_Move(motif, F_curr, float(numIterations)/MAXITERATIONS);
#ifdef _DEBUG
    fprintf(stderr,"SD_Move moved from %g to %g\n",F_curr,F_new);
#endif
    if (print_times) {
      time_t now_time = time(NULL);
      double rel_time = difftime(now_time,start_time);
      fprintf(stderr,"Iteration %d Time %.0f Score %g\n",numIterations,rel_time,F_new);
    }
    if (F_new <= F_curr) break;
    F_curr = F_new;
    fprintf(stderr,"Motif has %d sites\n",motif->Size());
    // cache->PrintCounts(stderr);    
    numIterations++;
  }

  cache->Destroy();
  for (int i=0; i<crms->Size(); i++) {
    Parameters::DeleteCacheSubsequenceProbabilities((*crms)[i]);
  }
  wmc->Remove(wmindex);
  delete W;

  delete cache;
  return F_curr;
}

double SD_Move(Motif *&motif, double F_cur, float temperature)
  // temperature: between 0 and 1. Proportional to the number of iterations so far.
  // higher temperature means less chance of doing SDBigMove.
  // NOT IMPLEMENTED YET.
{
  WtMx *curWM, *delWM;

  // construct weight matrix from current motif sites
  curWM = motif->ConstructWtMx();  
  int w = motif->GetMotifLength();
  
  // Check if this is the first iteration; if so, compute F_cur
  if (F_cur <= NEGINF) { 
    // Compute F() -- this will also put counts and derivatives in cache
    F_cur = -F(curWM); 
  }
  delete curWM; // dont need this anymore, since we are not computing deltas from curWM

  // the DELETION STEP.
  // First, delete one of the sites in the set "motif". Choose one that 
  // improves free energy.

  double F_cur_beforedelete = F_cur;

  // for all sites, actually delete it and compute change
  double *deltaDelete = new double[motif->Size()];
  for (int r = 0; r < motif->Size(); r++) {
    // delete site r
    int dindex = motif->GetNthValidIndex(r);
    motif->Delete(dindex);
    delWM = motif->ConstructWtMx();

    // compute the actual new score
    deltaDelete[r] = -F(delWM,false); // dont compute derivatives

    // undelete site r and restore to what it was before deletion
    motif->Undelete(dindex);
    delete delWM;
  }

  // choose the one that produces highest F
  double F_changed_max = -10000;
  int index_max = -1;
  for (int r = 0; r < motif->Size(); r++) {
    if (deltaDelete[r] > F_changed_max) {
      F_changed_max = deltaDelete[r];
      index_max = r;
    }
  }
  delete [] deltaDelete;
    
  // delete the chosen index
  int index_delete = -1, sequenceindex_delete = -1, offset_delete = -1;
  bool isreverse_delete = false;
  int dindex = motif->GetNthValidIndex(index_max);
  motif->Delete(dindex);

  // recompute the actual new score, so that counts and derivatives are put in cache
  // this is the only time the derivatives will be computed also.
  delWM = motif->ConstructWtMx();
  F_cur = -F(delWM);

  // note down what was deleted
  index_delete = dindex;
  sequenceindex_delete = motif->GetSequenceIndex(dindex);
  offset_delete = motif->GetOffset(dindex);
  isreverse_delete = motif->IsReverse(dindex);
  char *delete_site = new char[1024];
  motif->GetSite(index_delete,delete_site);  

#ifdef _DEBUG
  fprintf(stderr,"F  after deletion of site %s is %g\n",delete_site, F_cur);
#endif

  // have deleted something, resulting wtmx is delWM
  // Now the ADDITION STEP.

  // For each candidate site s_a, add s_a and estimate delta of F
  CacheDeltaF(delWM,motif,w);
  float ***candidate_scores = new float **[motif->NumSequences()];
  for (int i=0; i<motif->NumSequences(); i++) {
    Sequence *seq = motif->GetSequence(i);
    int length = seq->Length();
    candidate_scores[i] = new float*[length];
    for (int j=0; j<length; j++) {
      candidate_scores[i][j] = new float[2];
      for (int orient=0; orient<=1; orient++) candidate_scores[i][j][orient] = NEGINF; 
    }
    for (int j=0; j<=(length-w); j++) {
      for (int orient=0; orient <= 1; orient++) {
	// is s_a allowed ?
	if ((!overlap_allowed) && motif->OverlapsSomeSiteOrHasN(i,j)) continue;
	if (overlap_allowed && motif->HasN(i,j)) continue;

	// it is allowed, so compute what change in F it'll cause
	int *tryStr = new int[w+1];
	motif->GetSiteAsIndices(i,j,(orient==1), tryStr);
	double deltaF_addstep = EstimateDeltaFFast(w,tryStr,delWM);
	double F_new = F_cur + deltaF_addstep;	
	delete [] tryStr;
	
	// put the new F in an array
	candidate_scores[i][j][orient] = F_new;
	
      }
    }
  }
  delete delWM;

  // Evaluated the candidates ...
  // now make a move (ADDITION)
  // Traverse the candidate list in decreasing order of projected improvement
  // There is no pre-sorting; this is a simple MAXSORT.
  int numAttempts = 0;
  char **attempted = new char *[MAXATTEMPTSTOMOVE];
  for (int i=0; i<MAXATTEMPTSTOMOVE; i++) attempted[i] = NULL;
  bool success = false;
  while (numAttempts < MAXATTEMPTSTOMOVE) {
    // choose the best motif (the one that causes maximum projected increase in F)
    fprintf(stderr,"ATTEMPT TO ADD : %d\n",numAttempts+1);
    int chosen_i = -1; int chosen_j = -1; int chosen_orient = -1; 
    float chosen_F_new = -100000;
    for (int i=0; i<motif->NumSequences(); i++) {
      Sequence *seq = motif->GetSequence(i);
      int length = seq->Length();
      for (int j=0; j<(length-w+1); j++) {
	for (int orient=0; orient<=1; orient++) {
	  // First test if the addition is allowed
	  char str[1024];
	  for (int l=0; l<w; l++) str[l] = seq->CharAt(j+l);
	  str[w] = 0;
	  if (orient==1) {
	    char rev_str[1024];
	    Motif::ReverseComplement(rev_str,str);
	    strcpy(str,rev_str);
	  }
	  // do not allow addition of a site within 1 hamming distance of something already tried
	  bool reject = false;
	  for (int l=0; l<numAttempts; l++) {
	    if (attempted[l] == NULL) continue;
	    int hamdist = 0;
	    for (int l2=0; l2<w; l2++) {
	      if (attempted[l][l2] != str[l2]) hamdist++;
	    }
	    if (hamdist <= 1) reject = true;
	  }
	  if (reject) continue;
	  // also do not allow addition of the deleted site
	  if (!strcmp(str,delete_site)) continue;

	  // we want the candidate with maximum projected F
	  if (candidate_scores[i][j][orient] > chosen_F_new) {	      
	    chosen_i = i;
	    chosen_j = j;
	    chosen_orient = orient;
	    chosen_F_new = candidate_scores[i][j][orient];
	  }
	}
      }
    }
    if (chosen_i < 0 || chosen_j < 0 || chosen_orient < 0) {
      printf("Error: couldnt choose a move to make\n");
      exit(1);
    }
    
    // add site to motif
    int aindex = motif->Add(chosen_i,chosen_j,(chosen_orient==1));
    fprintf(stderr,"Added site  %d %d %d should give F_new of %g\n",chosen_i,chosen_j,chosen_orient,chosen_F_new);
    // see how it scores
    // construct weight matrix 
    WtMx *addWM = motif->ConstructWtMx();      
    // Compute F() -- this will also put counts in cache
    double F_new = -F(addWM,false); // dont  put the derivatives in now
#ifdef _DEBUG
    fprintf(stderr,"Added site gives F_new of %g\n",F_new);
#endif
    delete addWM;
    
    // if improvement found, exit the loop
    if (F_new > F_cur_beforedelete) {
      fprintf(stderr,"Added site accepted with new score %g\n",F_new);
      F_cur = F_new;
      success = true;

#ifdef _DEBUGCC
      FILE *fp = fopen("/tmp/plotdmotif.txt","w");
      for (int j=0; j<expr->getL(); j++) {
	fprintf(stderr,"%.3f\t%.3f\n",10*globalXj[j],globalYj[j]);
	fprintf(fp,"%d\t%.3f\t%.3f\n",j,10*globalXj[j],globalYj[j]);
      }
      fclose(fp);
      system("gnuplot helpers/wrap_gnuplot.plt");
      system("ggv /tmp/plotdmotif.ps &");
      getchar();
#endif

      break;      
    }
    else {
      // else make sure this wont be chosen; try the next best in next iteration
      char *str = attempted[numAttempts];
      motif->GetSite(aindex,str);
#ifdef _DEBUG
      fprintf(stderr,"Added site %s rejected ... trying another one\n",str);	  
#endif
      motif->Delete(aindex);
      candidate_scores[chosen_i][chosen_j][chosen_orient] = -10000;	  
      numAttempts++;	  
    }
  }
  if (!success) { 
    // Couldnt add a site, hence undelete and try BIG move
    // but cant call undelete, since a different site has been deleted in
    // the meantime (aindex), having the same index as index_delete
    motif->Add(sequenceindex_delete,offset_delete,isreverse_delete);
    
    // recompute the score 
    curWM = motif->ConstructWtMx();
    F_cur = -F(curWM,false); // no need to put derivatives
    delete curWM;

#ifdef _HOMOGENIZEMOVE
    // try the HomogenizeMove
    DTYPE F_old = F_cur;
    F_cur = SD_Homogenize_Move(motif, F_cur);
    if (F_cur <= F_old) {
      // then try the BIG move
      F_cur = SD_Big_Move(motif, F_cur);
    }
#else
  F_cur = SD_Big_Move(motif, F_cur);
#endif
  }
  
  // Clean up
  for (int i=0; i<MAXATTEMPTSTOMOVE; i++) {
    if (attempted[i] != NULL) delete [] attempted[i];
  }
  delete [] attempted;    
  for (int i=0; i<motif->NumSequences(); i++) {
    Sequence *seq = motif->GetSequence(i);
    int length = seq->Length();
    for (int j=0; j<length; j++) {
      delete [] candidate_scores[i][j];
    }
    delete [] candidate_scores[i];
  }
  delete [] candidate_scores;
  delete [] delete_site;
  
  return F_cur;
}


double SD_Homogenize_Move(Motif *motif, double F_cur)
{
  fprintf(stderr,"Motif before homogenize move\n");
  motif->Print(stderr);

  // construct a weight matrix
  WtMx *curWM = motif->ConstructWtMx();

  int nsites = motif->Size();
  int wmlen  = motif->GetMotifLength();
  DTYPE ***scores = new DTYPE **[motif->NumSequences()];
  // compute the best nsites occurrences of this curWM
  for (int i=0; i<motif->NumSequences(); i++) {
    // construct the sequence window
    Sequence *seq = motif->GetSequence(i);    
    int length = seq->Length(); 
    Window *win = new Window(seq,0,length-1);
    // also construct the bkgwm
    WtMx *bkgWM = NULL;
    if (global_background) bkgWM = global_background;
    else bkgWM = Parameters::TrainWtMx(win);

    // now compute the scores at each position and orientation
    scores[i] = new DTYPE*[length];
    for (int l=0; l < (length-wmlen+1); l++) {
      scores[i][l] = new DTYPE[2];
      bool hasAmbigChar = false;
      DTYPE bkgprob = 1;
      for (int k=0; k<wmlen; k++) {
	if (win->AmbiguousCharAt(l+k)) {
	  hasAmbigChar = true;
	  break;
	}
	bkgprob *= Parameters::ComputeSequenceProbability(win,l+k,l+k,bkgWM,false); 
      }
      if (hasAmbigChar) {	
	scores[i][l][0] = scores[i][l][1] = NEGINF;
	continue;
      }
      for (int orient=0; orient <= 1; orient++) {	
	curWM->SetForwardBias(1-orient);
	DTYPE score = log(Parameters::ComputeSequenceProbability(win,l,l+wmlen-1,curWM,false)) -log(bkgprob);
	scores[i][l][orient] = score; 
      }
    }
    if (global_background) bkgWM = NULL;
    else delete bkgWM;
    delete win;
  }
  
  // evaluated all locations, now pick the best nsites occurrences
  Motif hmotif;
  hmotif.SetMotifLength(wmlen);
  for (int i=0; i<motif->NumSequences(); i++) {
    hmotif.AddSequence(motif->GetSequence(i));
  }
  for (int count=0; count < nsites; count++) {
    DTYPE best_score = NEGINF;
    int chosen_i = -1; int chosen_l = -1; int chosen_orient = -1; 
    for (int i=0; i<motif->NumSequences(); i++) {
      Sequence *seq = motif->GetSequence(i);
      int length = seq->Length();
      for (int l=0; l<(length-wmlen+1); l++) {	
	for (int orient=0; orient<=1; orient++) {
	  if (scores[i][l][orient] > best_score) {
	    best_score = scores[i][l][orient];
	    chosen_i = i;
	    chosen_l = l;
	    chosen_orient = orient;
	  }
	}
      }
    }
    if (chosen_i < 0 || chosen_l < 0 || chosen_orient < 0) {
      printf("Error: couldnt choose a move to make\n");
      exit(1);
    }
    scores[chosen_i][chosen_l][chosen_orient] = NEGINF;
    scores[chosen_i][chosen_l][1-chosen_orient] = NEGINF;
    hmotif.Add(chosen_i,chosen_l,(chosen_orient==1));
  }

  fprintf(stderr,"homogenized Motif\n");
  hmotif.Print(stderr);

  // see how the homogenized matrix scores
  WtMx *hWM = hmotif.ConstructWtMx();
  double F_new = -F(hWM,false);
  if (F_new < F_cur) {
    // didnt find a better matrix
    // restore cache (w/o derivatives)
    F_cur = -F(curWM,false);
  }
  else {
    // found a better matrix
    F_cur = F_new;
    // change the motif
    motif->Clear();
    for (int i=0; i<hmotif.Size(); i++) {
      int iindex = hmotif.GetNthValidIndex(i);
      motif->Add(hmotif.GetSequenceIndex(iindex),hmotif.GetOffset(iindex),hmotif.IsReverse(iindex));
    }
  }
  delete hWM;

  // clean up
  for (int i=0; i<motif->NumSequences(); i++) {
    Sequence *seq = motif->GetSequence(i);
    int length = seq->Length();
    for (int l=0; l<(length-wmlen+1); l++) delete [] scores[i][l];
    delete [] scores[i];
  }
  delete [] scores;

  fprintf(stderr,"Motif after homogenize move\n");
  motif->Print(stderr);
  return F_cur;
}

double SD_Big_Move(Motif *motif, double F_cur)
{
  WtMx *curWM, *delWM;

  int w = motif->GetMotifLength();
  
  // This cannot be the first iteration, hence cache is in place.
  // dont assume derivatives are in cache.

  double F_cur_beforeadddel = F_cur;

  // for all sites, try deleting it ....
  float ****candidate_scores = new float ***[motif->Size()];
  for (int r = 0; r < motif->Size(); r++) {
    // delete site r
    int dindex = motif->GetNthValidIndex(r);
    motif->Delete(dindex);

    // recompute the actual new score, so that counts and derivatives are put in cache
    // this is the only time the derivatives will be computed also.
    delWM = motif->ConstructWtMx();
    F_cur = -F(delWM); // this computes derivatives also
    
    // note down what was deleted
    int index_delete = dindex;
    int sequenceindex_delete = motif->GetSequenceIndex(dindex);
    int offset_delete = motif->GetOffset(dindex);
    bool isreverse_delete = motif->IsReverse(dindex);

    // and try adding all candidates
    // For each candidate site s_a, add s_a and estimate delta of F
    CacheDeltaF(delWM,motif,w);
    candidate_scores[r] = new float **[motif->NumSequences()];
    for (int i=0; i<motif->NumSequences(); i++) {
      Sequence *seq = motif->GetSequence(i);
      int length = seq->Length();
      candidate_scores[r][i] = new float*[length];
      for (int j=0; j<length; j++) {
	candidate_scores[r][i][j] = new float[2];
	for (int orient=0; orient<=1; orient++) candidate_scores[r][i][j][orient] = NEGINF; 
      }
      for (int j=0; j<=(length-w); j++) {
	for (int orient=0; orient <= 1; orient++) {
	  // is s_a allowed ?
	  if ((!overlap_allowed) && motif->OverlapsSomeSiteOrHasN(i,j)) continue;
	  if (overlap_allowed && motif->HasN(i,j)) continue;

	  // it is allowed, so compute what change in F it'll cause
	  int *tryStr = new int[w+1];
	  motif->GetSiteAsIndices(i,j,(orient==1), tryStr);
	  double deltaF_addstep = EstimateDeltaFFast(w,tryStr,delWM);
	  double F_new = F_cur + deltaF_addstep;	
	  delete [] tryStr;

	  // put the new F in an array
	  candidate_scores[r][i][j][orient] = F_new;	  
	}
      }
    }

    // tried all possible additions following deletion of r-
    // "undelete" the site r. This brings "motif" back in sync with what it was
    motif->Add(sequenceindex_delete,offset_delete,isreverse_delete);    
    delete delWM;
  }

  // now actually try out the candidates adddels
  int numAttempts = 0;
  char **attempted = new char *[MAXATTEMPTSTOBIGMOVE];
  int *attempted_r = new int[MAXATTEMPTSTOBIGMOVE];
  int *countattempted_r = new int[motif->Size()];
  for (int i=0; i<MAXATTEMPTSTOBIGMOVE; i++) {
    attempted[i] = NULL;
    attempted_r[i] = -1;
  }
  for (int i=0; i<motif->Size(); i++) {
    countattempted_r[i] = 0;
  }
  bool success = false;
  while (numAttempts < MAXATTEMPTSTOBIGMOVE) {
    // choose the best motif (the one that causes maximum projected increase in F)
    fprintf(stderr,"ATTEMPT TO DEL-ADD : %d\n",numAttempts+1);
    int chosen_r = -1; int chosen_i = -1; int chosen_j = -1; int chosen_orient = -1; 
    float chosen_F_new = NEGINF;
    for (int r=0; r<motif->Size(); r++) {
      if (countattempted_r[r] > int(MAXATTEMPTSTOBIGMOVE/motif->Size())+1) continue;
      for (int i=0; i<motif->NumSequences(); i++) {
	Sequence *seq = motif->GetSequence(i);
	int length = seq->Length();
	for (int j=0; j<(length-w+1); j++) {
	  for (int orient=0; orient<=1; orient++) {
	    // First test if the addition is allowed
	    char str[1024];
	    for (int l=0; l<w; l++) str[l] = seq->CharAt(j+l);
	    str[w] = 0;
	    if (orient==1) {
	      char rev_str[1024];
	      Motif::ReverseComplement(rev_str,str);
	      strcpy(str,rev_str);
	    }
	    bool reject = false;
	    for (int l=0; l<numAttempts; l++) {
	      if (attempted[l] == NULL || attempted_r[l] != r) continue;
	      int hamdist = 0;
	      for (int l2=0; l2<w; l2++) {
		if (attempted[l][l2] != str[l2]) hamdist++;
	      }
	      if (hamdist <= 1) reject = true;
	    }
	    if (reject) continue;
	    
	    // we want the candidate with maximum projected F
	    if (candidate_scores[r][i][j][orient] > chosen_F_new) {	      
	      chosen_r = r;
	      chosen_i = i;
	      chosen_j = j;
	      chosen_orient = orient;
	      chosen_F_new = candidate_scores[r][i][j][orient];
	    }
	  }
	}
      }
    }
    if (chosen_r < 0 || chosen_i < 0 || chosen_j < 0 || chosen_orient < 0) {
      printf("Error: couldnt choose a move to make\n");
      exit(1);
    }

    // Delete site chosen_r
    int dindex = motif->GetNthValidIndex(chosen_r);
    motif->Delete(dindex);    

    // Record what was deleted
    int index_delete = dindex;
    int sequenceindex_delete = motif->GetSequenceIndex(dindex);
    int offset_delete = motif->GetOffset(dindex);
    bool isreverse_delete = motif->IsReverse(dindex);
    
    // add site to motif
    int aindex = motif->Add(chosen_i,chosen_j,(chosen_orient==1));

#ifdef _DEBUG
    fprintf(stderr,"Deleting site %d and Adding site %d %d %d should give F_new of %g\n",chosen_r,chosen_i,chosen_j,chosen_orient,chosen_F_new);
#endif
    
    // see how it scores
    // construct weight matrix 
    curWM = motif->ConstructWtMx();      
    // Compute F() -- this will also put counts in cache
    double F_new = -F(curWM,false); // no need to put derivatives
#ifdef _DEBUG
    fprintf(stderr,"Added site gives F_new of %g\n",F_new);
#endif
    delete curWM;
    
    // if improvement found, exit the loop
    if (F_new > F_cur_beforeadddel) {
      fprintf(stderr,"Del-Added site accepted\n");
      F_cur = F_new;
      success = true;
      break;      
    }
    else {
      // else make sure this wont be chosen; try the next best in next iteration
      char *str = attempted[numAttempts];
      motif->GetSite(aindex,str);
      attempted_r[numAttempts] = chosen_r;
      countattempted_r[chosen_r]++;
      fprintf(stderr,"Deleting site %d and Adding site %s rejected ... trying another one\n",chosen_r,str);
      // Delete what had been added
      motif->Delete(aindex);
      // ... And add back what had been deleted
      motif->Add(sequenceindex_delete,offset_delete,isreverse_delete);    
      candidate_scores[chosen_r][chosen_i][chosen_j][chosen_orient] = NEGINF;	  
      numAttempts++;
    }
  }
  if (!success) { // Couldnt del-add a site
    // recompute the score
    curWM = motif->ConstructWtMx();
    F_cur = -F(curWM,false); // no need to put derivatives
    delete curWM;
  }
  
  // Clean up
  for (int i=0; i<MAXATTEMPTSTOBIGMOVE; i++) {
    if (attempted[i] != NULL) delete [] attempted[i];
  }
  delete [] attempted;    
  delete [] attempted_r;
  delete [] countattempted_r;
  for (int r=0; r<motif->Size(); r++) {
    for (int i=0; i<motif->NumSequences(); i++) {
      Sequence *seq = motif->GetSequence(i);
      int length = seq->Length();
      for (int j=0; j<length; j++) {
	delete [] candidate_scores[r][i][j];
      }
      delete [] candidate_scores[r][i];
    }
    delete [] candidate_scores[r];
  }
  delete [] candidate_scores;

#ifdef _DEBUG
  fprintf(stderr,"SD_Big_Move returns %g\n",F_cur);
#endif

  return F_cur;
}

/////////////////////////////////////////////////////////////////////////////////////
///// next two functions implement a fast method to compute deltaF for each /////////
///// possible addition of site to motif ////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////

void CacheDeltaF(WtMx *curWM, Motif *motif, int wm_len)
{
  for (int l=0; l<wm_len; l++) {
    // compute the grad for this position, with respect to each k
    double *d_lk = new double[4];
    for (int k=0; k<4; k++) 
      d_lk[k] = -GradF(curWM,l,k);

    // for each possible delta vector
    for (int ch=0; ch<4; ch++) {
      float *delta = motif->ComputeDeltaVector(ch, l, curWM);
      // compute the deltaF
      DTYPE sum = 0;
      for (int k=0; k<4; k++) 
	sum += d_lk[k]*delta[k];
      // and store it
      cache->deltaF_lk[l][ch] = sum;
      
      delete [] delta;
    }

    delete [] d_lk;
  }
}

double EstimateDeltaFFast(int w, int *tryStr, WtMx *curWM)
  // tryStr is an array of 0-3
{
  double deltaF = 0;
  for (int l=0; l<w; l++) {
    deltaF += cache->deltaF_lk[l][tryStr[l]];
  }

  return deltaF;
}

/////////////////////////////////////////////////////////////////////////////////////
//// This does the dynamic programming (for counts as well as derivatives, if ///////
//// needed) for each sequence (crm) and stores the results in cache. ///////////////
//// These results are then used later (from the cache) by F(), Grad() etc. /////////
/////////////////////////////////////////////////////////////////////////////////////

void TrainOnCRM(int i, bool derivatives)
{

  Sequence *seq = (*crms)[i];  

  WindowIterator wi(seq);
  bool did_begin = wi.Begin(seq->Length(),10); 
  if (!did_begin || wi.End()) {
    printf("Error: Internal problems in Eta() function\n");
    exit(1);
  }
  
  vector<Window *> *wl = new vector<Window *>;
  wi.CurrentWindowList(wl);
  
  // train with all matrices
  Parameters_Deriv *paramd = new Parameters_Deriv;
  int bkgIndex = paramd->BackgroundIndex(wmc);
  paramd->Initialize(wl,wmc,bkgIndex);
  if (wmindex >= 0) 
    paramd->SetFreeWMIndex(wmindex);
  if (!cache->usepriors) {
    if (cache->trainfreewmandbkgonly) {
      paramd->SetParameters(cache->priors[i]);
      for (int j=0; j<paramd->NumWM(); j++) {
	if (j != bkgIndex && j != wmindex) { 
	  paramd->FixTransitionProbabilities(j);
	}
      }
    }
    paramd->Train();
    for (int j=0; j<paramd->NumWM(); j++)
      cache->priors[i][j] = paramd->GetParameter(j);
  }
  else {
    paramd->SetParameters(cache->priors[i]);
    paramd->TrainWithFixedParameters();
  }

  if (wmindex >= 0) {
    DTYPE count = paramd->ComputeAverageCount(wmindex);
    cache->counts[i] = count;
  }

  if (derivatives) {
    if (wmindex < 0) {
      printf("Error: derivative computation requested without wmindex set\n");
      exit(1);
    }
    paramd->PrecomputeDerivatives();
    int wmlength = wmc->WM(wmindex)->Length();
    for (int k=0; k<wmlength; k++) {
      for (int alpha=0; alpha<4; alpha++) {
	DTYPE deriv = paramd->ComputeAverageCountDerivative(k,alpha);
	cache->derivs[i][k][alpha] = deriv;
      }
    }
  }
  delete paramd;
  for (int windex=0; windex<wl->size(); windex++) {
    Window *win =  (*wl)[windex];
    delete win;
  }
  delete wl;
}

//////////////////////////////////////////////////////////////////////////////////////////////
// Implements two different scores:
// (i) CORRELATIONCOEFFICIENT: looks at all positions (between 0 and _L-1) that
//     are **valid** and computes correlation coefficient of average count with TF expression.
//(ii) TSCORE: for each position, treats the valid sequences as "+ve" and invalid sequences
//     as "-ve" and computed a t-score for the average count of these two classes.
//(iii)LOGISTICSCORE: as in TSCORE, but function is least squares differernce of (valid_i==1) 
//     and logistic(count_i) for each sequence i
// IMPORTANT : returns NEGATIVE correlation coeff or t-score or least squares
//////////////////////////////////////////////////////////////////////////////////////////////

double F(WtMx *W, bool derivatives)
{
  // first change the weight matrix \phi
  WtMx *wm = wmc->WM(wmindex);
  for (int i=0; i<wm->Length(); i++) {
    DTYPE updatefreq[4];
    for (int j=0; j<4; j++) {
      updatefreq[j] = W->Frequency(i,j);
    }
    wm->UpdateFrequency(i,(DTYPE *)updatefreq);
  }

  // then recompute Stubb stuff (counts, derivs etc.)
  // and put it into cache.
  cache->Clear();
  for (int i=0; i<crms->Size(); i++) {
    TrainOnCRM(i,derivatives);
  }

  // now use cache to compute F1

#ifdef _CORRELATIONCOEFFICIENT  
  int J = expr->getL();
  int *K4j = new int[J];
  for (int j=0; j<J; j++) {
    int sum = 0;
    for (int i=0; i<crms->Size(); i++) {
      if (!locations[i][j]) continue;
      sum++;
    }
    K4j[j] = sum;
  }

  double X=0, Y=0, Xsqr=0, Ysqr=0, XY=0;

  int numValid = 0;
  for (int j=0; j<J; j++) {
    if (!expr->IsValid(j)) continue;
    numValid++;
    float Xj = (*expr)[j];
    DTYPE sumcount = 0;
    for (int i=0; i<crms->Size(); i++) {
      if (!locations[i][j]) continue;
#ifdef _NORMALIZECRMLENGTHS
      sumcount += cache->counts[i]/((*crms)[i]->Length()) * 1000;
#else
      sumcount += cache->counts[i];
#endif
    }
    float Yj = sumcount;
    if (K4j[j] > 0) Yj /= K4j[j];
#ifdef _DEBUGCC
    globalXj[j] = Xj;
    globalYj[j] = Yj;
#endif
    X += Xj;
    Y += Yj;
    Xsqr += pow(Xj,2);
    Ysqr += pow(Yj,2);
    XY += Xj*Yj;
  }

  X /= numValid; Y /= numValid; Xsqr /= numValid; Ysqr /= numValid; XY /= numValid;
  
#ifdef _CORRSQR
  double F1 = pow((XY - X*Y),2)/((Xsqr-pow(X,2))*(Ysqr-pow(Y,2)));// square of corr. coeff.
#else
#ifdef _NONORMALIZEY
  double F1 = (XY - X*Y)/sqrt(((Xsqr-pow(X,2))));                 // special corr. coeff.: no normalization for Y
#else
  double F1 = (XY - X*Y)/sqrt(((Xsqr-pow(X,2))*(Ysqr-pow(Y,2)))); //  corr. coeff.
#endif // _NONORMALIZEY
#endif // _CORRSQR  
  delete [] K4j;
#endif // _CORRELATIONCOEFFCIENT

#ifdef _LOGISTICSCORE
  double Y = 0;
  for (int j=0; j<crms->Size(); j++) {
    DTYPE Yj;
#ifdef _NORMALIZECRMLENGTHS
    Yj = cache->counts[j]/((*crms)[j]->Length()) * 1000;
#else
    Yj = cache->counts[j];
#endif
    
    Y += pow((2/(1+exp(-WFACTOR*Yj)) - 1 - (expr->IsValid(j)?1:0)),2);
  }

  DTYPE F1 = -Y;
#endif // _LOGISTICSCORE

#ifdef _TSCORE 
  int N1 = 0, N2 = 0;
  double Z=0, Y=0, Zsqr=0, Ysqr=0;
  for (int j=0; j<crms->Size(); j++) {
    DTYPE Yj;
#ifdef _NORMALIZECRMLENGTHS
    Yj = cache->counts[j]/((*crms)[j]->Length()) * 1000;
#else
    Yj = cache->counts[j];
#endif
    
    if (expr->IsValid(j)) {      
      Y += Yj;
      Ysqr += pow(Yj,2);
      N1++;
    }
    else {
      Z += Yj;
      Zsqr += pow(Yj,2);
      N2++;
    }
  }
  
#ifdef _SAMPLESTD // standard deviation in T-score from the sample; the standard definition
  if (N1 <= 1 || N2 <= 1) {
    printf("Sample size is one or less ... Cant compute t\n");
    exit(1);
  }
  double s1sqr = N1/(N1-1)*(Ysqr/N1 - pow(Y/N1,2));
  double s2sqr = N2/(N2-1)*(Zsqr/N2 - pow(Z/N2,2));
  double F1 = ((Y/N1)-(Z/N2))/sqrt(s1sqr/N1+s2sqr/N2);
#else  // simply the difference of means
  if (N1 <= 0 || N2 <= 0) {
    printf("Sample size is zero or less ... Cant compute t\n");
    exit(1);
  }
  double F1 = (Y/N1)-(Z/N2);
#endif // _SAMPLESTD
#endif // _TSCORE

  return -F1;
}


double GradF(WtMx *W, int k, int alpha)
{
  // use cache to compute F1'
#ifdef _CORRELATIONCOEFFICIENT  
  int J = expr->getL();
  int *K4j = new int[J];
  for (int j=0; j<J; j++) {
    int sum = 0;
    for (int i=0; i<crms->Size(); i++) {
      if (!locations[i][j]) continue;
      sum++;
    }
    K4j[j] = sum;
  }

  double X=0, Y=0, Xsqr=0, Ysqr=0, XY=0, XdY=0, dY=0, YdY=0;

  int numValid = 0;
  for (int j=0; j<J; j++) {
    if (!expr->IsValid(j)) continue;
    numValid++;
    float Xj = (*expr)[j];
    DTYPE sumcount = 0;
    for (int i=0; i<crms->Size(); i++) {
      if (!locations[i][j]) continue;
#ifdef _NORMALIZECRMLENGTHS
      sumcount += cache->counts[i]/((*crms)[i]->Length()) * 1000;
#else
      sumcount += cache->counts[i];
#endif
    }
    float Yj = sumcount;
    if (K4j[j] > 0) Yj /= K4j[j];

    X += Xj;
    Y += Yj;
    Xsqr += pow(Xj,2);
    Ysqr += pow(Yj,2);
    XY += Xj*Yj;

    DTYPE derivterm = 0;
    for (int i=0; i<crms->Size(); i++) {
      if (!locations[i][j]) continue;
#ifdef _NORMALIZECRMLENGTHS
      derivterm += cache->derivs[i][k][alpha]/((*crms)[i]->Length()) * 1000;
#else
      derivterm += cache->derivs[i][k][alpha];
#endif
    }
    float dYj = derivterm;
    if (K4j[j] > 0) dYj /= K4j[j];
    
    dY += dYj;
    YdY += Yj*dYj;
    XdY += Xj*dYj;    
  }

  X /= numValid; Y /= numValid; Xsqr /= numValid; Ysqr /= numValid; XY /= numValid;
  dY /= numValid; YdY /= numValid; XdY /= numValid;

#ifdef _CORRSQR
  double dN = 2*(XY - X*Y)*(XdY - X*dY);
  double dD = (Xsqr - pow(X,2))*2*(YdY - Y*dY);
  double N = pow((XY - X*Y),2);
  double D = (Xsqr-pow(X,2))*(Ysqr-pow(Y,2));  
#else
  double dN = (XdY - X*dY);
  double dD = sqrt((Xsqr - pow(X,2))/(Ysqr - pow(Y,2)))*(YdY - Y*dY);
  double N = (XY - X*Y);
  double D = sqrt((Xsqr-pow(X,2))*(Ysqr-pow(Y,2)));  
#endif

#ifdef _NONORMALIZEY
  double F1_d = dN/D;
#else
  double F1_d = dN/D - N/pow(D,2)*dD;
#endif // _NONORMALIZEY
  delete [] K4j;
#endif // _CORRELATIONCOEFFICIENT

#ifdef _LOGISTICSCORE
  double Y_d = 0;
  for (int j=0; j<crms->Size(); j++) {
    DTYPE Yj, dYj;
#ifdef _NORMALIZECRMLENGTHS
    Yj = cache->counts[j]/((*crms)[j]->Length()) * 1000;
    dYj = cache->derivs[j][k][alpha]/((*crms)[j]->Length()) * 1000;
#else
    Yj = cache->counts[j];
    dYj = cache->derivs[j][k][alpha];
#endif

    DTYPE logisticdenom = 1+exp(-WFACTOR*Yj);
    Y_d += 2*(2/logisticdenom - 1 - (expr->IsValid(j)?1:0))*(-2)/pow(logisticdenom,2)*(logisticdenom-1)*-WFACTOR*dYj;
  }

  DTYPE F1_d = -Y_d;
#endif // _LOGISTICSCORE

#ifdef _TSCORE
  int N1 = 0, N2 = 0;
  double Z=0, Y=0, Zsqr=0, Ysqr=0, dY=0, dZ=0, YdY=0, ZdZ=0;
  for (int j=0; j<crms->Size(); j++) {
    DTYPE Yj, dYj;
#ifdef _NORMALIZECRMLENGTHS
    Yj = cache->counts[j]/((*crms)[j]->Length()) * 1000;
    dYj = cache->derivs[j][k][alpha]/((*crms)[j]->Length()) * 1000;
#else
    Yj = cache->counts[j];
    dYj = cache->derivs[j][k][alpha];
#endif

    if (expr->IsValid(j)) {      
      Y += Yj;
      Ysqr += pow(Yj,2);
      dY += dYj;
      YdY += Yj*dYj;
      N1++;
    }
    else {
      Z += Yj;
      Zsqr += pow(Yj,2);
      dZ += dYj;
      ZdZ += Yj*dYj;
      N2++;
    }
  }

#ifdef _SAMPLESTD
  if (N1 <= 1 || N2 <= 1) {
    printf("Sample size is one or less ... Cant compute t\n");
    exit(1);
  }
  double s1sqr = N1/(N1-1)*(Ysqr/N1 - pow(Y/N1,2));
  double s2sqr = N2/(N2-1)*(Zsqr/N2 - pow(Z/N2,2));
  double ds1sqr = N1/(N1-1)*(2*YdY/N1 - 2*(Y/N1)*(dY/N1));
  double ds2sqr = N2/(N2-1)*(2*ZdZ/N2 - 2*(Z/N2)*(dZ/N2));
  double D = sqrt(s1sqr/N1+s2sqr/N2);  
  double F1_d = (dY/N1 - dZ/N2)/D - (Y/N1-Z/N2)/pow(D,3)*(ds1sqr/N1 + ds2sqr/N2);
#else  // simply a difference of means
  if (N1 <= 0 || N2 <= 0) {
    printf("Sample size is one or less ... Cant compute t\n");
    exit(1);
  }
  double F1_d = (dY/N1)-(dZ/N2);
#endif // _SAMPLESTD
#endif // _TSCORE

#ifdef _NOGRAD
  return -1;
#endif
  return -F1_d;
}

//////////////////////////////////////////////////////////////////////////////////////
//// These routines implement F() and Grad() with WM's as vectors, ///////////////////
//////////////////////////////////////////////////////////////////////////////////////

double F_raw(double *x)
{
  int wmlength = wmc->WM(wmindex)->Length();
  double **wtmx = new double *[wmlength];
  int ptr = 1;
  for (int i=0; i<wmlength; i++) {
    wtmx[i] = new double[4];
    double max = -10000000;
    for (int j=0; j<4; j++) {
      wtmx[i][j] = x[ptr++];
      if (wtmx[i][j] > max) max = wtmx[i][j];
    }
    double sum = 0;
    for (int j=0; j<4; j++) {
      wtmx[i][j] -= max;
      wtmx[i][j] = exp(wtmx[i][j]);
      sum += wtmx[i][j];
    }
    for (int j=0; j<4; j++) {
      wtmx[i][j] /= sum;
    }
  }

  float **wm = new float *[4];
  for (int i=0; i<4; i++) {
    wm[i] = new float[wmlength];
    for (int j=0; j<wmlength; j++) {
      wm[i][j] = wtmx[j][i];
    }
  }
  
  WtMx *w = new WtMx(wm,wmlength,"TempWtMx",0);
  double func = F(w);

  for (int i=0; i<4; i++) {
    delete [] wm[i];
  }
  delete [] wm;
  
  for (int i=0; i<wmlength; i++) {
    delete [] wtmx[i];
  }
  delete [] wtmx;
  delete w;

#ifdef _DEBUG
  fprintf(stderr,"Current score : %g\n",func);
#endif
  return func;
}

void Grad_raw(double *x, double *grad)
{
  int wmlength = wmc->WM(wmindex)->Length();
  double **wtmx = new double *[wmlength];
  int ptr = 1;
  for (int i=0; i<wmlength; i++) {
    wtmx[i] = new double[4];
    double max = -10000000;
    for (int j=0; j<4; j++) {
      wtmx[i][j] = x[ptr++];
      if (wtmx[i][j] > max) max = wtmx[i][j];
    }
    double sum = 0;
    for (int j=0; j<4; j++) {
      wtmx[i][j] -= max;
      wtmx[i][j] = exp(wtmx[i][j]);
      sum += wtmx[i][j];
    }
    for (int j=0; j<4; j++) {
      wtmx[i][j] /= sum;
    }
  }

  float **wm = new float *[4];
  for (int i=0; i<4; i++) {
    wm[i] = new float[wmlength];
    for (int j=0; j<wmlength; j++) {
      wm[i][j] = wtmx[j][i];
    }
  }
  
  WtMx *w = new WtMx(wm,wmlength,"TempWtMx",0);
  ptr = 1;
  for (int k=0; k<wmlength; k++) {
    for (int alpha=0; alpha<4; alpha++) {      
      double dfunc = GradF(w,k,alpha);
      dfunc *= w->Frequency(k,alpha);
      grad[ptr++] = dfunc;
    }
  }

  for (int i=0; i<4; i++) {
    delete [] wm[i];
  }
  delete [] wm;
  
  for (int i=0; i<wmlength; i++) {
    delete [] wtmx[i];
  }
  delete [] wtmx;
  delete w;

  return;
}


